<style>
    body .wp-site-blocks,
    body .wp-block-group,
    body main,
    body .entry-content,
    body .wp-block-post-content {
        max-width: 100% !important;
        padding: 0 !important;
    }
    body, html {
        overflow-x: hidden !important;
        max-width: 100vw !important;
    }
    
    * {
        box-sizing: border-box;
    }
    
    /* Material Icons alignment */
    .material-icons {
        vertical-align: middle;
    }
</style>

<!-- Google Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
<?php

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="tcr-wrapper">
    <div class="hero-gradient tcr-hero-section">
        <div class="tcr-content-area">
           <div class="screen">
                <h1 class="tcr-hero-title" style="font-weight: 800; color: #fff;">Your Path to Tech Success</h1>
                <p class="tcr-hero-subtitle" style="font-weight: 400; opacity: 50%;">
                    Explore curated roadmaps for career advancement and professional certifications. <br>
                    Learn the skills that matter, earn recognized credentials, and advance your tech career.
                </p>
                <div class="flex">
                    <div class="tcr-stat-box">
                        <div class="text-3xl font-bold" style="display: flex; align-items: center; gap: 0.5rem;">
                           
                            <?php echo count($career_roadmaps); ?>+
                        </div>
                        <div class="text-sm">Career Paths</div>
                    </div>
                    <div class="tcr-stat-box">
                        <div class="text-3xl font-bold" style="display: flex; align-items: center; gap: 0.5rem;">
                            
                            <?php echo count($cert_roadmaps); ?>+
                        </div>
                        <div class="text-sm">Certifications</div>
                    </div>
                    <div class="tcr-stat-box">
                        <div class="text-3xl font-bold" style="display: flex; align-items: center; gap: 0.5rem;">
                          
                            1000+
                        </div>
                        <div class="text-sm">Resources</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="background-color: #fff; border-bottom: 1px solid #e2e8f0;">
        <div class="tcr-content-area" style="padding: 1rem 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;">
                <button 
                    class="tcr-tab-button tab-button active"
                    data-tab="career"
                    style="display: flex; align-items: center; gap: 0.5rem;"
                >
                    <span class="material-icons" style="font-size: 1.125rem;">work</span>
                    Career Paths
                </button>
                <button 
                    class="tcr-tab-button tab-button"
                    data-tab="certification"
                    style="display: flex; align-items: center; gap: 0.5rem;"
                >
                    <span class="material-icons" style="font-size: 1.125rem;">verified</span>
                    Certifications
                </button>
                <button 
                    class="tcr-tab-button tab-button"
                    data-tab="#"
                    style="display: flex; align-items: center; gap: 0.5rem;"
                >
                    <span class="material-icons" style="font-size: 1.125rem;">swap_horiz</span>
                    Migration Paths
                </button>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem; max-width: 400px; width: 100%; padding: 0.5rem 1rem; border: 1px solid #d1d5db; border-radius: 0.5rem;">
                <span class="material-icons" style="color: #9ca3af; font-size: 1.125rem;">search</span>
                <input 
                    type="text" 
                    placeholder="Search roadmaps..." 
                    class="tcr-search-input"
                    style="flex: 1; border: none; outline: none; font-size: 14px;"
                />
            </div>
        </div>
    </div>
    
    <div style="background-color: #f7fafc;">
        
        <div class="tcr-tab-content fade-in" data-tab="career">
            <?php if (empty($career_roadmaps)): ?>
                <div class="tcr-content-area">
                    <div style="text-align: center; padding: 4rem 1rem; color: #6b7280;">
                        <span class="material-icons" style="font-size: 4rem; opacity: 0.5; margin-bottom: 1rem;">folder_open</span>
                        <p style="font-size: 1.125rem;">No career roadmaps available yet.</p>
                        <p style="font-size: 0.875rem; margin-top: 0.5rem;">Check back soon or contact the administrator.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="tcr-content-area">
                    <div class="tcr-card-grid">
                       <?php foreach ($career_roadmaps as $roadmap): 
                            $roadmap_id = $roadmap->ID;
                            $icon = get_post_meta($roadmap_id, '_tcr_icon', true) ?: '💼';
                            $color = get_post_meta($roadmap_id, '_tcr_color', true);
                            
                            if (empty($color)) {
                                $color = '#3b82f6, #8b5cf6';
                            }
                            
                            $colors = array_map('trim', explode(',', $color));
                            $color1 = isset($colors[0]) && !empty($colors[0]) ? $colors[0] : '#3b82f6';
                            $color2 = isset($colors[1]) && !empty($colors[1]) ? $colors[1] : '#8b5cf6';
                            
                            $avg_salary = get_post_meta($roadmap_id, '_tcr_avg_salary', true) ?: 'N/A';
                            $duration = get_post_meta($roadmap_id, '_tcr_duration', true) ?: 'N/A';
                            $experience_level = get_post_meta($roadmap_id, '_tcr_experience_level', true) ?: 'Beginner';
                            $skills = get_post_meta($roadmap_id, '_tcr_skills', true) ?: '';
                            $skills_array = !empty($skills) ? array_map('trim', explode(',', $skills)) : array();
                            $learning_path = json_decode(get_post_meta($roadmap_id, '_tcr_learning_path', true), true) ?: array();
                            $modules_count = count($learning_path);
                            $description = wp_trim_words($roadmap->post_content, 15, '...');
                        ?>
                        
                        <a 
                            href="<?php echo esc_url(get_permalink($roadmap_id)); ?>" 
                            class="card" 
                            style="text-decoration: none; display: flex; flex-direction: column; height: 100%;"
                        >
                            <div style="padding: 2rem; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between;">
                                <div style="flex-grow: 1; display: flex; flex-direction: column; justify-content: flex-start;">
                                    
                                    <div style="display: flex; align-items: flex-start; gap: 1rem; margin-bottom: 1rem;">
                                        <div class="icon-badge text-white" style="background: linear-gradient(135deg, <?php echo esc_attr($color1); ?>, <?php echo esc_attr($color2); ?>);">
                                            <?php echo esc_html($icon); ?>
                                        </div>
                                        <div style="flex: 1; min-width: 0;">
                                            <h3 style="font-size: 1.25rem; font-weight: 700; color: #1f2937; margin: 0 0 0.5rem 0;">
                                                <?php echo esc_html($roadmap->post_title); ?>
                                            </h3>
                                            <p style="color: #4b5563; font-size: 0.85rem; margin: 0; line-height: 1.5;">
                                                <?php 
                                                $short_desc = get_post_meta($roadmap_id, '_tcr_short_description', true);
                                                if (empty($short_desc)) {
                                                    $short_desc = wp_trim_words(strip_tags($roadmap->post_content), 8, '');
                                                }
                                                if (strlen($short_desc) > 50) {
                                                    $short_desc = substr($short_desc, 0, 50);
                                                    $short_desc = substr($short_desc, 0, strrpos($short_desc, ' '));
                                                    $short_desc .= '...';
                                                }
                                                echo esc_html($short_desc); 
                                                ?>
                                            </p>
                                        </div>
                                    </div>

                                    <div style="margin-bottom: 1rem; display: flex; flex-direction: column; gap: 0.5rem;">
                                        <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem;">
                                            <span class="material-icons" style="color: #6b7280; font-size: 1rem;">payments</span>
                                            <span style="font-weight: 600; color: #047857;"><?php echo esc_html($avg_salary); ?></span>
                                            <span style="color: #9ca3af;">avg. salary</span>
                                        </div>
                                        <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem;">
                                            <span class="material-icons" style="color: #6b7280; font-size: 1rem;">schedule</span>
                                            <span style="color: #4b5563;"><?php echo esc_html($duration); ?></span>
                                            <span style="color: #9ca3af;">•</span>
                                            <span class="material-icons-outlined" style="color: #6b7280; font-size: 0.97rem;">folder</span>
                                            <span style="color: #4b5563;"><?php echo esc_html($modules_count); ?> modules</span>
                                        </div>
                                        <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem;">
                                            <span class="material-icons" style="color: #6b7280; font-size: 1rem;">bar_chart</span>
                                            <span style="color: #4b5563;"><?php echo esc_html($experience_level); ?></span>
                                        </div>
                                    </div>

                                    <?php if (!empty($skills_array)): ?>
                                    <div style="margin-bottom: 1rem; margin-top: auto;">
                                        <div style="font-size: 0.75rem; font-weight: 600; color: #6b7280; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.25rem;">
                                            <span class="material-icons" style="font-size: 0.875rem;">psychology</span>
                                            KEY SKILLS
                                        </div>
                                        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                                            <?php foreach (array_slice($skills_array, 0, 5) as $skill): ?>
                                                <span class="tcr-skill-tag">
                                                    <?php echo esc_html($skill); ?>
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    
                                </div>
                                
                                <div style="border-top: 1px solid #e5e7eb; padding-top: 1rem;">
                                    <span style="color: #fb923c; font-weight: 600; text-decoration: none; font-size: 1rem; display: flex; align-items: center; gap: 0.25rem;" onmouseover="this.style.color='#c2410c';" onmouseout="this.style.color='#fb923c';" onfocus="this.style.outline='none';">
                                        View Roadmap
                                        <span class="material-icons" style="font-size: 1.125rem;">arrow_forward</span>
                                    </span>
                                </div>
                            </div>
                        </a>
                        
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="tcr-tab-content fade-in" data-tab="certification" style="display: none;">
            <?php if (empty($cert_roadmaps)): ?>
                <div class="tcr-content-area">
                    <div style="text-align: center; padding: 4rem; color: #6b7280;">
                        <span class="material-icons" style="font-size: 4rem; opacity: 0.5; margin-bottom: 1rem;">folder_open</span>
                        <p style="font-size: 1.125rem;">No certification roadmaps available yet.</p>
                        <p style="font-size: 0.875rem; margin-top: 0.5rem;">Check back soon or contact the administrator.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="tcr-content-area">
                    <div class="tcr-card-grid">
                        <?php foreach ($cert_roadmaps as $cert): 
                            $cert_id = $cert->ID;
                            $icon = get_post_meta($cert_id, '_tcr_icon', true) ?: '🏆';
                            $color = get_post_meta($cert_id, '_tcr_color', true);
                            
                            if (empty($color)) {
                                $color = '#10b981, #14b8a6';
                            }
                            
                            $colors = array_map('trim', explode(',', $color));
                            $color1 = isset($colors[0]) && !empty($colors[0]) ? $colors[0] : '#10b981';
                            $color2 = isset($colors[1]) && !empty($colors[1]) ? $colors[1] : '#14b8a6';
                            
                            $provider = get_post_meta($cert_id, '_tcr_provider', true) ?: 'N/A';
                            $level = get_post_meta($cert_id, '_tcr_level', true) ?: 'Associate';
                            $exam_cost = get_post_meta($cert_id, '_tcr_exam_cost', true) ?: 'N/A';
                            $estimated_time = get_post_meta($cert_id, '_tcr_estimated_time', true) ?: 'N/A';
                            $description = wp_trim_words($cert->post_content, 15, '...');
                        ?>
                        
                        <a href="<?php echo esc_url(get_permalink($cert_id)); ?>" style="text-decoration: none; display: block;">
                            <div class="card" style="cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease;" 
                                 onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 12px 24px rgba(0,0,0,0.15)';" 
                                 onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='';">
                                <div style="padding: 2rem;"> 
                                    <div style="display: flex; align-items: flex-start; gap: 1rem; margin-bottom: 0.5rem;"> 
                                        <div class="icon-badge text-white" style="background: linear-gradient(135deg, <?php echo esc_attr($color1); ?>, <?php echo esc_attr($color2); ?>);">
                                            <?php echo esc_html($icon); ?>
                                        </div>
                                        <div style="flex: 1; min-width: 0;">
                                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem; flex-wrap: wrap;">
                                                <h3 style="font-size: 1.25rem; font-weight: 900; color: #1f2937; margin-top: 0; margin-bottom: 0.25rem;">
                                                    <?php echo esc_html($cert->post_title); ?>
                                                </h3>
                                                <span style="padding: 0.25rem 0.5rem; background-color: #dbeafe; color: #1d4ed8; font-size: 0.75rem; font-weight: 600; border-radius: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">
                                                    <span class="material-icons" style="font-size: 0.875rem;">military_tech</span>
                                                    <?php echo esc_html($level); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.75rem; margin-bottom: 0.75rem;"> 
                                        <div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.5rem;"> 
                                            <div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">
                                                <span class="material-icons" style="font-size: 0.875rem;">schedule</span>
                                                Study Time
                                            </div>
                                            <div style="font-weight: 600; color: #1f2937; font-size: 1rem;"><?php echo esc_html($estimated_time); ?></div> 
                                        </div>
                                        
                                        <div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.5rem;">
                                            <div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">
                                                <span class="material-icons" style="font-size: 0.875rem;">payments</span>
                                                Exam Cost
                                            </div>
                                            <div style="font-weight: 600; color: #1f2937; font-size: 1rem;"><?php echo esc_html($exam_cost); ?></div>
                                        </div>
                                    </div>

                                    <div style="border-top: 1px solid #e5e7eb; padding-top: 0.75rem;"> 
                                        <span style="color: #fb923c; font-weight: 600; text-decoration: none; font-size: 1rem; display: flex; align-items: center; gap: 0.25rem;" onmouseover="this.style.color='#c2410c';" onmouseout="this.style.color='#fb923c';" onfocus="this.style.outline='none';">
                                            View Roadmap
                                            <span class="material-icons" style="font-size: 1.125rem;">arrow_forward</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </a>
                        
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="tcr-content-area">
            <div class="tcr-empty-state" style="display: none;">
                <span class="material-icons" style="font-size: 4rem; opacity: 0.5; margin-bottom: 1rem;">search_off</span>
                <p style="font-size: 1.125rem; font-weight: 500;">No roadmaps match your search</p>
                <p style="font-size: 0.875rem;">Try different keywords or browse all roadmaps</p>
            </div>
        </div>
    </div>

    <footer style="background-color: #1f2937; color: white; padding-top: 3rem; padding-bottom: 3rem;">
        <div class="tcr-content-area" style="text-align: center; font-size: 0.875rem; color: #9ca3af;">
            <p>&copy; <?php echo date('Y'); ?> <?php echo get_bloginfo('name'); ?>. Powered by Tutorials Dojo.</p>
        </div>
    </footer>
</div>