<?php
/**
 * Template for displaying single roadmap
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get the global $post and $data variables
global $post;

// If data isn't set, get it from the post
if (!isset($data)) {
    $tcr = new TechCareerRoadmaps();
    $reflection = new ReflectionClass($tcr);
    $method = $reflection->getMethod('get_roadmap_data');
    $method->setAccessible(true);
    $data = $method->invoke($tcr, $post);
}

$is_career = $post->post_type === 'career_roadmap';
$roadmap_id = $data['id'];
$learning_path = $data['learningPath'];

// Parse gradient colors with better error handling
$color_value = $data['color'];
if (empty($color_value)) {
    $color_value = '#3b82f6, #8b5cf6';
}

$colors = array_map('trim', explode(',', $color_value));
$color1 = isset($colors[0]) && !empty($colors[0]) ? $colors[0] : '#3b82f6';
$color2 = isset($colors[1]) && !empty($colors[1]) ? $colors[1] : '#8b5cf6';

// Calculate initial progress
$total_subgoals = 0;
foreach ($learning_path as $module) {
    if (isset($module['subGoals'])) {
        $total_subgoals += count($module['subGoals']);
    }
}

// Store all modules data in data attribute for JavaScript access
$modules_json = wp_json_encode($learning_path);

function render_module_detail($module, $index, $total_modules, $total_subgoals) {
    $subgoals = $module['subGoals'] ?? array();
    $subgoal_count = count($subgoals);
    
    ob_start();
    ?>
    <div class="detail-card">
        <div style="padding: 1.5rem; border-bottom: 1px solid #f3f4f6; background-color: white; border-top-left-radius: 0.75rem; border-top-right-radius: 0.75rem;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; flex-wrap: wrap;">
                <div>

                    <h2 class="tcr-module-title">
                        <?php echo esc_html($module['title']); ?>
                    </h2>
            
                    <span class="tcr-module-completion">
                        0/<?php echo $subgoal_count; ?> milestones completed
                    </span>
                </div>
           
                <button class="tcr-mark-complete">
                    <span class="material-icons" style="font-size: 1.125rem;">check_circle</span>
                    Mark Complete
                </button>
            </div>
        </div>

        <div style="padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem;">
            <h3 style="font-size: 1rem; font-weight: 700; color: #A9A9A9; border-bottom: 1px solid #e5e7eb; padding-bottom: 0.5rem; display: flex; align-items: center; gap: 0.5rem;">
                <span class="material-icons" style="font-size: 1.25rem;">flag</span>
                Learning Milestones
            </h3>

            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                <?php foreach ($subgoals as $sg_index => $subgoal): 
                    $checkbox_id = 'sg-' . sanitize_title($module['title']) . '-' . sanitize_title($subgoal['title']);
                    $resources = $subgoal['resources'] ?? array();
                ?>
                <div class="tcr-milestone">
                    <label for="<?php echo esc_attr($checkbox_id); ?>" style="width: 100%; display: flex; align-items: flex-start; gap: 0.75rem; cursor: pointer;">
                        <input
                            type="checkbox"
                            id="<?php echo esc_attr($checkbox_id); ?>"
                            class="tcr-subgoal-checkbox"
                            data-module="<?php echo $index; ?>"
                            data-subgoal="<?php echo $sg_index; ?>"
                        >
                        <div style="flex: 1;">
                            <p class="tcr-subgoal-title">
                                <?php echo esc_html($subgoal['title']); ?>
                            </p>
                            
                            <?php if (!empty($resources)): ?>
                            <div style="margin-top: 1rem; font-size: 0.75rem; color: #6b7280; display: flex; flex-direction: column; gap: 0.5rem;">
                                <span style="font-weight: 600; color: #6b7280; display: flex; align-items: center; gap: 0.25rem;">
                                    <span class="material-icons" style="font-size: 1rem;">library_books</span>
                                    Resources:
                                </span>
                                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                                    <?php foreach ($resources as $resource): ?>
                                    <a 
                                        href="<?php echo esc_url($resource['url']); ?>" 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        class="tcr-resource-link"
                                        onclick="event.stopPropagation();"
                                    >
                                        <span class="material-icons" style="font-size: 0.875rem;">link</span>
                                        <?php echo esc_html($resource['name']); ?>
                                    </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; font-size: 0.875rem; border-top: 1px solid #f3f4f6;">
            <button 
                class="tcr-nav-button tcr-prev-module" 
                <?php echo $index === 0 ? 'disabled' : ''; ?>
            >
                <span class="material-icons" style="font-size: 1.125rem;">arrow_back</span>
                Previous
            </button>

            <span style="color: #6b7280;">
                <?php echo $index + 1; ?> of <?php echo $total_modules; ?>
            </span>

            <button 
                class="tcr-nav-button tcr-next-module"
                style="color: #FFA726;"
                <?php echo $index === $total_modules - 1 ? 'disabled' : ''; ?>
            >
                Next
                <span class="material-icons" style="font-size: 1.125rem;">arrow_forward</span>
            </button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Google Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    
    <style>
        /* Force full-width - CRITICAL overrides */
        * {
            box-sizing: border-box;
        }

        body, html {
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            overflow-x: hidden !important;
        }

        /* Override ALL WordPress theme wrappers */
        body > *:not(.tcr-wrapper):not(script):not(style),
        #page,
        #content,
        .site,
        .site-content,
        .wp-site-blocks,
        .wp-block-group,
        main,
        main.wp-block-group,
        .entry-content,
        .wp-block-post-content,
        article {
            max-width: none !important;
            width: 100% !important;
            padding: 0 !important;
            margin: 0 !important;
        }

        /* Ensure tcr-wrapper takes full width */
        .tcr-wrapper {
            width: 100vw !important;
            margin: 0 !important;
            padding: 0 !important;
            background: white;
        }

        .roadmap-container {
            display: flex;
            min-height: 100vh;
            max-width: 1280px;
            margin: 0 auto;
        }
        
        /* Hide WordPress admin bar spacing */
        body.admin-bar {
            margin-top: 0 !important;
        }
        
        /* Material Icons vertical alignment */
        .material-icons {
            vertical-align: middle;
        }
    </style>
    <?php wp_head(); ?>
    
    <style>
    /* Additional inline styles for single roadmap page */
    .roadmap-container {
        display: flex;
        min-height: 100vh;
        max-width: 1280px;
        margin: 0 auto;
    }

    .roadmap-left-panel {
        width: 30%;
        flex-shrink: 0;
        background-color: white;
        border-right: 1px solid #e2e8f0;
        padding-left: 2rem;
        padding-right: 2rem;
        position: sticky;
        top: 0;
        height: 100vh;
        overflow-y: auto;
        padding-top: 2rem;
        padding-bottom: 2rem;
    }

    .roadmap-main-content {
        flex-grow: 1;
        padding: 2rem;
        background-color: #f7fafc;
        min-width: 0;
    }
    
    /* Fix roadmap step line positioning */
    .roadmap-step {
        position: relative;
        padding-left: 2rem;
        padding-bottom: 0;
        min-height: 80px;
    }
    
    .roadmap-step:not(:last-child)::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 0.5rem;
        height: calc(100% + 0px);
        width: 2px;
        background-color: #cbd5e1;
        z-index: 1;
    }
    
    .roadmap-dot {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 0;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        border: 3px solid white;
        z-index: 10;
        transition: all 0.2s ease;
    }

    @media (max-width: 1024px) {
        .roadmap-container {
            flex-direction: column;
        }
        
        .roadmap-left-panel {
            width: 100%;
            height: auto;
            position: relative;
            border-right: none;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .roadmap-main-content {
            margin-left: 0 !important;
        }
    }

    .fade-in {
        animation: fadeIn 0.5s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    </style>
</head>
<body <?php body_class('roadmap-body'); ?> data-roadmap-id="<?php echo esc_attr($roadmap_id); ?>">

<div class="tcr-wrapper">
    <div class="roadmap-container">
        
        <div class="roadmap-left-panel">
            <div id="roadmap-left-panel-content" style="padding-top: 2.5rem;">
                <?php 
                // Determine the correct back URL with tab parameter
                $back_url = home_url('/tech-career-roadmaps/');
                if (!$is_career) {
                    // For certifications, add the tab parameter to activate certifications tab
                    $back_url = add_query_arg('tab', 'certification', $back_url);
                }
                ?>
                <a href="<?php echo esc_url($back_url); ?>" class="tcr-back-button" style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-door-fill" viewBox="0 0 16 16">
                      <path d="M6.5 14.5v-3.505c0-.245.25-.495.5-.495h2c.25 0 .5.25.5.5v3.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5"/>
                    </svg>
                    <h6 style="font-weight: 700; margin: 0;">Back to Roadmaps</h6>
                </a>

                <h2 style="font-size: 1.25rem; font-weight: 800; margin-bottom: 1rem; margin-top: 2rem; color: #1f2937; display: flex; align-items: center; gap: 0.5rem;">
                    Learning Path
                </h2>
                
                <div style="margin-bottom: 1.5rem;">
                    <div style="display: flex; justify-content: space-between; font-size: 0.875rem; font-weight: 500; color: #4b5563; margin-bottom: 0.5rem;">
                        <span style="display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 1rem;">trending_up</span>
                            Progress
                        </span>
                        <span id="tcr-progress-text" class="tcr-progress-text">
                            0% complete (0/<?php echo $total_subgoals; ?> steps)
                        </span>
                    </div>
                    <div style="width: 100%; background-color: #e5e7eb; border-radius: 9999px; height: 0.5rem;">
                        <div
                            id="tcr-progress-bar"
                            style="background: linear-gradient(to right, #60a5fa, #234C6A); height: 100%; border-radius: 9999px; width: 0%; transition: width 0.7s ease;"
                            role="progressbar"
                            aria-valuenow="0"
                            aria-valuemin="0"
                            aria-valuemax="100"
                        ></div>
                    </div>
                </div>

                <div style="display: flex; flex-direction: column; gap: 0;">
                    <?php foreach ($learning_path as $module_index => $module): ?>
                    <div class="roadmap-step" data-module-index="<?php echo $module_index; ?>">
                        <div class="roadmap-dot <?php echo $module_index === 0 ? 'active' : 'bg-gray-400'; ?>"></div>
                        <button
                            class="tcr-module-button tcr-select-module <?php echo $module_index === 0 ? 'active' : 'hover:bg-gray-100'; ?>"
                            data-module-index="<?php echo $module_index; ?>"
                            style="margin-bottom: 0;"
                        >
                            <span class="text-xs">
                                Step <?php echo $module_index + 1; ?> of <?php echo count($learning_path); ?>
                            </span>
                            <h4 class="text-base">
                                <?php echo esc_html($module['title']); ?>
                            </h4>
                            <p style="font-size: 0.875rem; color: #6b7280; margin-top: 0.25rem; line-height: 1.25rem;">
                                <?php echo esc_html($module['shortDesc'] ?? 'Click to view details.'); ?>
                            </p>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <div class="roadmap-main-content">
            
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 0.5rem; margin-left: 1rem; padding-top: 2.5rem;">
                <?php 
                $icon = !empty($data['icon']) ? $data['icon'] : '💼';
                ?>
                <div class="icon-badge text-white" style="background: linear-gradient(135deg, <?php echo esc_attr($color1); ?>, <?php echo esc_attr($color2); ?>); font-size: 28px;">
                    <?php echo $icon; ?>
                </div>
                <div>
                    <h1 style="font-size: 2.25rem; font-weight: 800; color: #1f2937;">
                        <?php echo esc_html($data['title']); ?>
                    </h1>
                    
                    <?php if ($is_career): ?>
                    <div style="font-size: 0.75rem; display: flex; align-items: center; gap: 0.5rem; margin-top: -1rem; flex-wrap: wrap;">
                        <span style="font-weight: 600; color: #4b5563; background-color: #e5e7eb; border-radius: 9999px; padding: 0.25rem 0.5rem; border: 1px solid #f3f4f6; display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 0.875rem;">payments</span>
                            <?php echo esc_html($data['avgSalary']); ?>
                        </span>
                        <span style="font-weight: 600; color: #4b5563; background-color: #e5e7eb; border-radius: 9999px; padding: 0.25rem 0.5rem; border: 1px solid #f3f4f6; display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 0.875rem;">schedule</span>
                            <?php echo esc_html($data['duration']); ?>
                        </span>
                        <span style="font-weight: 600; color: #4b5563; background-color: #e5e7eb; border-radius: 9999px; padding: 0.25rem 0.5rem; border: 1px solid #f3f4f6; display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 0.875rem;">bar_chart</span>
                            <?php echo esc_html($data['experienceLevel']); ?>
                        </span>
                    </div>
                    <?php else: ?>
                    <div style="font-size: 0.75rem; color: #4b5563; display: flex; align-items: center; gap: 0.5rem; margin-top: -1rem; flex-wrap: wrap;">
                        <span style="font-weight: 600; color: #4b5563; background-color: #e5e7eb; border-radius: 9999px; padding: 0.25rem 0.5rem; border: 1px solid #f3f4f6; display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 0.875rem;">payments</span>
                            <?php echo esc_html($data['examCost']); ?>
                        </span>
                        <span style="font-weight: 600; color: #4b5563; background-color: #e5e7eb; border-radius: 9999px; padding: 0.25rem 0.5rem; border: 1px solid #f3f4f6; display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 0.875rem;">schedule</span>
                            <?php echo esc_html($data['estimatedTime']); ?>
                        </span>
                        <span style="font-weight: 600; color: #4b5563; background-color: #e5e7eb; border-radius: 9999px; padding: 0.25rem 0.5rem; border: 1px solid #f3f4f6; display: flex; align-items: center; gap: 0.25rem;">
                            <span class="material-icons" style="font-size: 0.875rem;">workspace_premium</span>
                            <?php echo esc_html($data['provider']); ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div style="font-size: 0.875rem; color: #4b5563; margin-top: 2rem; margin-bottom: 2rem; max-width: 50rem;">
                <?php echo wp_kses_post($data['description']); ?>
            </div>
            
            <div id="tcr-detail-panel" class="fade-in" style="margin-bottom: 2.5rem;">
                <?php 
                if (!empty($learning_path)) {
                    echo render_module_detail($learning_path[0], 0, count($learning_path), $total_subgoals);
                } else {
                    ?>
                    <div class="tcr-empty-state" style="text-align: center; padding: 4rem 2rem; color: #6b7280; background-color: white; border-radius: 0.75rem; border: 1px solid #e5e7eb;">
                        <span class="material-icons" style="font-size: 4rem; opacity: 0.5; margin-bottom: 1rem;">info</span>
                        <h3 style="font-size: 1.25rem; font-weight: 700;">No Learning Path Defined</h3>
                        <p style="font-size: 1rem; margin-top: 0.5rem;">The roadmap is currently empty. Please add modules and subgoals in the WordPress editor.</p>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>

<script>
// Store module data for JavaScript
window.tcrModulesData = <?php echo $modules_json; ?>;
window.tcrCurrentIndex = 0;
window.tcrTotalModules = <?php echo count($learning_path); ?>;

// Initialize isCompleted flags
if (window.tcrModulesData) {
    window.tcrModulesData.forEach(function(module) {
        if (module.subGoals) {
            module.subGoals.forEach(function(sg) {
                if (sg.isCompleted === undefined) {
                    sg.isCompleted = false;
                }
            });
        }
    });
}

// Function to render module content dynamically
function renderModuleContent(index) {
    if (index < 0 || index >= window.tcrTotalModules) return;
    
    var module = window.tcrModulesData[index];
    var subgoals = module.subGoals || [];
    
    var html = '<div class="detail-card">';
    html += '<div style="padding: 1.5rem; border-bottom: 1px solid #f3f4f6; background-color: white; border-top-left-radius: 0.75rem; border-top-right-radius: 0.75rem;">';
    html += '<div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; flex-wrap: wrap;">';
    html += '<div>';
    // Module title with YOUR exact custom styling
    html += '<h2 class="tcr-module-title">' + module.title + '</h2>';
    html += '<span class="tcr-module-completion">';
    html += '</div>';
    html += '<button class="tcr-mark-complete">';
    html += '<span class="material-icons" style="font-size: 1.125rem;">check_circle</span> Mark Complete</button>';
    html += '</div></div>';
    
    html += '<div style="padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem;">';
    html += '<h3 style="font-size: 1rem; font-weight: 700; color: #A9A9A9; border-bottom: 1px solid #e5e7eb; padding-bottom: 0.5rem; display: flex; align-items: center; gap: 0.5rem;"><span class="material-icons" style="font-size: 1.25rem;">flag</span>Learning Milestones</h3>';
    html += '<div style="display: flex; flex-direction: column; gap: 0.75rem;">';
    
    subgoals.forEach(function(subgoal, sgIdx) {
        var checkboxId = 'sg-' + window.TCRoadmap.createSlug(module.title) + '-' + window.TCRoadmap.createSlug(subgoal.title);
        var resources = subgoal.resources || [];
        var isChecked = subgoal.isCompleted || false;
        
        html += '<div class="tcr-milestone">';
        html += '<label for="' + checkboxId + '" style="width: 100%; display: flex; align-items: flex-start; gap: 0.75rem; cursor: pointer;">';
        html += '<input type="checkbox" id="' + checkboxId + '" class="tcr-subgoal-checkbox" ' + (isChecked ? 'checked' : '') + ' style="width: 1.25rem; height: 1.25rem; margin-top: 0.25rem; flex-shrink: 0; accent-color: #10b981; cursor: pointer; background-color: white;" data-module="' + index + '" data-subgoal="' + sgIdx + '">';
        html += '<div style="flex: 1;">';
        // Subgoal title with YOUR exact custom styling
        html += '<p class="tcr-subgoal-title">' + subgoal.title + '</p>';
        
        if (resources.length > 0) {
            html += '<div style="margin-top: 1rem; font-size: 0.75rem; color: #6b7280; display: flex; flex-direction: column; gap: 0.5rem;">';
            html += '<span style="font-weight: 600; color: #6b7280; display: flex; align-items: center; gap: 0.25rem;"><span class="material-icons" style="font-size: 1rem;">library_books</span>Resources:</span>';
            html += '<div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">';
            resources.forEach(function(resource) {
                html += '<a href="' + resource.url + '" target="_blank" rel="noopener noreferrer" class="tcr-resource-link" onclick="event.stopPropagation();"><span class="material-icons" style="font-size: 0.875rem;">link</span>' + resource.name + '</a>';
            });
            html += '</div></div>';
        }
        
        html += '</div></label></div>';
    });
    
    html += '</div></div>';
    
    html += '<div style="display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; font-size: 0.875rem; border-top: 1px solid #f3f4f6;">';
    html += '<button class="tcr-nav-button tcr-prev-module" ' + (index === 0 ? 'disabled' : '') + '>';
    html += '<span class="material-icons" style="font-size: 1.125rem;">arrow_back</span>Previous</button>';
    html += '<span style="color: #6b7280;">' + (index + 1) + ' of ' + window.tcrTotalModules + '</span>';
    html += '<button class="tcr-nav-button tcr-next-module" style="color: #FFA726;" ' + (index === window.tcrTotalModules - 1 ? 'disabled' : '') + '>';
    html += 'Next<span class="material-icons" style="font-size: 1.125rem;">arrow_forward</span></button></div>';
    
    html += '</div>';
    
    jQuery('#tcr-detail-panel').html(html);
    window.tcrCurrentIndex = index;
    
    if (window.TCRoadmap && window.TCRoadmap.loadProgress) {
        jQuery('.tcr-subgoal-checkbox').each(function() {
            var $checkbox = jQuery(this);
            var mIdx = $checkbox.data('module');
            var sgIdx = $checkbox.data('subgoal');
            
            if (window.tcrModulesData[mIdx] && 
                window.tcrModulesData[mIdx].subGoals && 
                window.tcrModulesData[mIdx].subGoals[sgIdx]) {
                
                $checkbox.prop('checked', window.tcrModulesData[mIdx].subGoals[sgIdx].isCompleted);
            }
        });
    }

    if (window.TCRoadmap && window.TCRoadmap.updateProgress) {
        window.TCRoadmap.updateProgress();
    }
}

jQuery(document).ready(function($) {
    setTimeout(function() {
        if (window.TCRoadmap && window.TCRoadmap.loadProgress) {
            window.TCRoadmap.loadProgress();
        }
    }, 500);
});
</script>

<?php wp_footer(); ?>
</body>
</html>