(function($) {
    'use strict';

    const editor = {
        modules: [],
        $uiContainer: $('#tcr-learning-path-editor-ui'),
        $jsonOutput: $('#tcr_learning_path'),

        init: function() {
            this.loadModulesFromJSON(); 
            
            this.bindEvents();
            this.render();
            this.updateJsonOutput();
        },
        
        loadModulesFromJSON: function() {
             try {
                const initialJson = window.tcrInitialLearningPathJSON;
                if (initialJson) {
                    this.modules = JSON.parse(initialJson);
                } else {
                    this.modules = [];
                }
            } catch (e) {
                console.error("Failed to parse initial JSON. Starting with empty array.", e);
                this.modules = [];
            }
        },

        bindEvents: function() {
            const self = this;
            
            this.$jsonOutput.on('keyup change paste', function() {
                clearTimeout(self.jsonUpdateTimer);
                self.jsonUpdateTimer = setTimeout(function() {
                    self.syncFormFromJSON();
                }, 750);
            });

            $('#tcr-add-module').on('click', function(e) {
                e.preventDefault();
                self.addModule();
            });

            this.$uiContainer.on('input', '.tcr-module-input', function() {
                self.updateModuleFromInput($(this));
            });
            
            this.$uiContainer.on('input', '.tcr-subgoals-json', function() {
                self.updateSubGoalsFromInput($(this));
            });

            this.$uiContainer.on('click', '.tcr-delete-module', function(e) {
                e.preventDefault();
                const index = $(this).data('index');
                self.deleteModule(index);
            });
            
            if ($.fn.sortable) {
                this.$uiContainer.sortable({
                    handle: '.tcr-module-handle',
                    items: '.tcr-module-card',
                    axis: 'y',
                    update: function(event, ui) {
                        self.reorderModules();
                    }
                });
            }
        },
        
        syncFormFromJSON: function() {
            try {
                const newJson = this.$jsonOutput.val();
                const newModules = JSON.parse(newJson);
                
                if (Array.isArray(newModules)) {
                    this.modules = newModules;
                    this.$jsonOutput.css('border-color', '#38a169');
                    this.render();
                } else {
                    this.$jsonOutput.css('border-color', '#e53e3e');
                }
            } catch (e) {
                this.$jsonOutput.css('border-color', '#e53e3e');
                console.error("Invalid JSON detected, cannot rebuild form.", e);
            }
        },

        reorderModules: function() {
            const self = this;
            let newOrder = [];
            
            this.$uiContainer.find('.tcr-module-card').each(function() {
                const oldIndex = $(this).data('index');
                self.updateSubGoalsFromInput($(this).find('.tcr-subgoals-json'));
                newOrder.push(self.modules[oldIndex]);
            });
            
            this.modules = newOrder;
            this.render();
            this.updateJsonOutput();
        },
        
        addModule: function() {
            const newModule = {
                "title": "New Module Title",
                "shortDesc": "A brief description for the homepage card.",
                "subGoals": [{
                    "title": "New Milestone 1",
                    "resources": [{
                        "name": "Resource Name",
                        "url": "http://example.com/link"
                    }]
                }]
            };
            this.modules.push(newModule);
            this.render();
            this.updateJsonOutput();
        },

        deleteModule: function(index) {
            if (confirm('Are you sure you want to delete this module? This action cannot be undone.')) {
                this.modules.splice(index, 1);
                this.render();
                this.updateJsonOutput();
            }
        },
        
        updateModuleFromInput: function($input) {
            const index = $input.data('index');
            const field = $input.data('field');
            
            this.modules[index][field] = $input.val();
            this.updateJsonOutput();
        },
        
        updateSubGoalsFromInput: function($textarea) {
            const index = $textarea.data('index');
            const subGoalsJson = $textarea.val();
            
            try {
                const newSubGoals = JSON.parse(subGoalsJson);
                
                if (Array.isArray(newSubGoals)) {
                    this.modules[index].subGoals = newSubGoals;
                    $textarea.css('border-color', '#38a169');
                } else {
                    $textarea.css('border-color', '#e53e3e');
                    return;
                }
            } catch (e) {
                $textarea.css('border-color', '#e53e3e');
                return;
            }
            
            this.updateJsonOutput();
        },

        render: function() {
            const self = this;
            this.$uiContainer.empty();
            
            if (this.modules.length === 0) {
                this.$uiContainer.html('<div style="text-align: center; padding: 30px; color: #666; border: 2px dashed #ddd; border-radius: 8px;">No modules defined. Click "Add New Module" to start.</div>');
                return;
            }
            
            this.modules.forEach(function(module, index) {
                let subGoalsJsonString;
                try {
                    subGoalsJsonString = JSON.stringify(module.subGoals, null, 2);
                } catch (e) {
                    subGoalsJsonString = "[]";
                }

                const $card = $(`
                    <div class="tcr-module-card postbox closed" data-index="${index}" style="margin-bottom: 20px; border: 1px solid #ddd; border-radius: 6px;">
                        <div class="hndle tcr-module-handle" style="cursor: move; padding: 10px 15px; font-size: 16px; background: #f9f9f9; border-bottom: 1px solid #ddd;">
                            <span class="dashicons dashicons-move" style="margin-right: 8px;"></span>
                            Module ${index + 1}: **${module.title || 'Untitled'}**
                            <button type="button" class="tcr-delete-module button button-small" data-index="${index}" style="float: right; color: #a00; border-color: #fbd3d3;">
                                <span class="dashicons dashicons-trash"></span> Delete
                            </button>
                        </div>
                        <div class="inside" style="padding: 15px;">
                            <div class="tcr-form-group" style="margin-bottom: 15px;">
                                <label for="tcr_title_${index}" style="display: block; font-weight: 600; margin-bottom: 5px;">Module Title:</label>
                                <input type="text" id="tcr_title_${index}" data-index="${index}" data-field="title" value="${module.title || ''}" class="tcr-module-input large-text" placeholder="e.g., Fundamentals of Cybersecurity" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            </div>
                            <div class="tcr-form-group" style="margin-bottom: 15px;">
                                <label for="tcr_shortDesc_${index}" style="display: block; font-weight: 600; margin-bottom: 5px;">Short Description (Card text):</label>
                                <input type="text" id="tcr_shortDesc_${index}" data-index="${index}" data-field="shortDesc" value="${module.shortDesc || ''}" class="tcr-module-input large-text" placeholder="A brief description for the homepage card." style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            </div>
                            <div class="tcr-form-group">
                                <label style="display: block; font-weight: 600; margin-bottom: 5px;">Milestones / Subgoals (JSON Format for fine control):</label>
                                <p class="description">Edit the JSON below for subgoals. It must be a valid array of objects. **Use a JSON validator if unsure!**</p>
                                <textarea data-index="${index}" class="tcr-subgoals-json large-text code" rows="8" style="min-height: 200px; font-family: monospace; width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">${subGoalsJsonString}</textarea>
                            </div>
                        </div>
                    </div>
                `);
                
                self.$uiContainer.append($card);
            });
            
            if (typeof postboxes === 'object' && typeof postboxes.add_postbox_toggles === 'function') {
                 postboxes.add_postbox_toggles(pagenow);
            }
        },

        updateJsonOutput: function() {
            const self = this;
            
            const cleanedModules = this.modules.map(module => {
                const cleanedModule = {};
                
                cleanedModule.title = module.title || '';
                cleanedModule.shortDesc = module.shortDesc || '';
                
                let subGoalsArray = [];
                try {
                    subGoalsArray = Array.isArray(module.subGoals) ? module.subGoals : JSON.parse(JSON.stringify(module.subGoals)); 
                    if (!Array.isArray(subGoalsArray)) {
                        subGoalsArray = [];
                    }
                } catch(e) {
                    subGoalsArray = [];
                }
                cleanedModule.subGoals = subGoalsArray;
                
                return cleanedModule;
            });
            
            try {
                const finalJson = JSON.stringify(cleanedModules, null, 0);
                this.$jsonOutput.val(finalJson);
                this.$jsonOutput.css('border-color', '#ddd');
            } catch (e) {
                console.error("Failed to generate final JSON.", e);
                this.$jsonOutput.css('border-color', '#e53e3e');
            }
        }
    };

    $(document).ready(function() {
        editor.init();
    });

})(jQuery);