(function($) {
    'use strict';

    const TCRShortcode = {
        pageType: null, // Will be set from tcrShortcode.pageType

        init: function() {
            // Set page type from localized script
            this.pageType = (typeof tcrShortcode !== 'undefined') ? tcrShortcode.pageType : 'both';
            
            this.bindEvents();
            this.updateOutputs();
        },

        bindEvents: function() {
            // Tab switching
            $('.tcr-tab-btn').on('click', this.switchTab);
            
            // Career roadmap selection
            $('#career-select').on('change', this.handleCareerSelect);
            
            // Certification selection
            $('#cert-select').on('change', this.handleCertSelect);
            
            // Cards shortcode builder - handle different types based on page
            $('#cards-limit, #cards-ids').on('change keyup', this.handleCardsChange);
            
            // Copy button clicks
            $('.tcr-copy-btn').on('click', this.copyToClipboard);
        },

        switchTab: function(e) {
            e.preventDefault();
            const tab = $(this).data('tab');
            
            // Update tab buttons
            $('.tcr-tab-btn').removeClass('active');
            $(this).addClass('active');
            
            // Update tab content
            $('.tcr-tab-content').removeClass('active');
            $('#' + tab + '-tab').addClass('active');
        },

        handleCareerSelect: function() {
            const selectedId = $(this).val();
            const selectedText = $(this).find('option:selected').text();
            
            if (selectedId) {
                // Update shortcode output
                $('#career-shortcode-output').text('[career_roadmap id="' + selectedId + '"]');
                
                // Fetch and display preview
                TCRShortcode.fetchPreview(selectedId, 'career_roadmap', '#career-preview');
            } else {
                $('#career-shortcode-output').text('[career_roadmap id=""]');
                $('#career-preview').html('<p class="tcr-no-selection">Select a roadmap to see preview</p>');
            }
        },

        handleCertSelect: function() {
            const selectedId = $(this).val();
            const selectedText = $(this).find('option:selected').text();
            
            if (selectedId) {
                // Update shortcode output
                $('#cert-shortcode-output').text('[certification_roadmap id="' + selectedId + '"]');
                
                // Fetch and display preview
                TCRShortcode.fetchPreview(selectedId, 'cert_roadmap', '#cert-preview');
            } else {
                $('#cert-shortcode-output').text('[certification_roadmap id=""]');
                $('#cert-preview').html('<p class="tcr-no-selection">Select a certification to see preview</p>');
            }
        },

        handleCardsChange: function() {
            const limit = $('#cards-limit').val();
            const ids = $('#cards-ids').val().trim();
            
            // Determine type based on current page
            let type = TCRShortcode.pageType || 'both';
            
            let shortcode = '[roadmap_cards';
            
            // Add type attribute
            if (type !== 'both') {
                shortcode += ' type="' + type + '"';
            }
            
            // Add limit attribute if not showing all
            if (limit !== '-1') {
                shortcode += ' limit="' + limit + '"';
            }
            
            // Add ids attribute if specified
            if (ids !== '') {
                shortcode += ' ids="' + ids + '"';
            }
            
            shortcode += ']';
            
            $('#cards-shortcode-output').text(shortcode);
        },

        fetchPreview: function(postId, postType, targetSelector) {
            const $preview = $(targetSelector);
            
            // Show loading
            $preview.html('<p class="tcr-no-selection">Loading preview...</p>');
            
            // Fetch post meta
            $.ajax({
                url: tcrShortcode.ajaxurl,
                type: 'POST',
                data: {
                    action: 'tcr_get_roadmap_preview',
                    nonce: tcrShortcode.nonce,
                    post_id: postId,
                    post_type: postType
                },
                success: function(response) {
                    if (response.success) {
                        TCRShortcode.renderPreview(response.data, targetSelector, postType);
                    } else {
                        $preview.html('<p class="tcr-no-selection">Error loading preview</p>');
                    }
                },
                error: function() {
                    $preview.html('<p class="tcr-no-selection">Error loading preview</p>');
                }
            });
        },

        renderPreview: function(data, targetSelector, postType) {
            const $preview = $(targetSelector);
            
            // Parse gradient colors
            let gradient = 'linear-gradient(135deg, #3b82f6, #8b5cf6)';
            if (data.color) {
                const colors = data.color.split(',').map(c => c.trim());
                if (colors.length >= 2) {
                    gradient = `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`;
                }
            }
            
            let html = '<div class="tcr-preview-card" style="background: ' + gradient + ';">';
            html += '<div style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px;">';
            html += '<div style="font-size: 32px;">' + (data.icon || '💼') + '</div>';
            html += '<h4 style="margin: 0;">' + data.title + '</h4>';
            html += '</div>';
            
            html += '<div class="tcr-preview-meta">';
            
            if (postType === 'career_roadmap') {
                if (data.avgSalary) {
                    html += '<span><span class="dashicons dashicons-money-alt"></span> ' + data.avgSalary + '</span>';
                }
                if (data.duration) {
                    html += '<span><span class="dashicons dashicons-clock"></span> ' + data.duration + '</span>';
                }
                if (data.experienceLevel) {
                    html += '<span><span class="dashicons dashicons-chart-line"></span> ' + data.experienceLevel + '</span>';
                }
            } else {
                if (data.provider) {
                    html += '<span><span class="dashicons dashicons-awards"></span> ' + data.provider + '</span>';
                }
                if (data.level) {
                    html += '<span><span class="dashicons dashicons-star-filled"></span> ' + data.level + '</span>';
                }
                if (data.examCost) {
                    html += '<span><span class="dashicons dashicons-money-alt"></span> ' + data.examCost + '</span>';
                }
            }
            
            html += '</div>';
            html += '</div>';
            
            $preview.html(html);
        },

        copyToClipboard: function(e) {
            e.preventDefault();
            const targetId = $(this).data('target');
            const $target = $('#' + targetId);
            const text = $target.text();
            
            // Create temporary textarea
            const $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val(text).select();
            
            try {
                document.execCommand('copy');
                TCRShortcode.showToast();
                
                // Update button text temporarily
                const $btn = $(this);
                const originalHtml = $btn.html();
                $btn.html('<span class="dashicons dashicons-yes"></span> Copied!');
                
                setTimeout(function() {
                    $btn.html(originalHtml);
                }, 2000);
            } catch (err) {
                console.error('Failed to copy:', err);
            }
            
            $temp.remove();
        },

        showToast: function() {
            const $toast = $('#tcr-toast');
            $toast.addClass('show');
            
            setTimeout(function() {
                $toast.removeClass('show');
            }, 3000);
        },

        updateOutputs: function() {
            // Initialize based on page type
            const type = this.pageType || 'both';
            
            $('#career-shortcode-output').text('[career_roadmap id=""]');
            $('#cert-shortcode-output').text('[certification_roadmap id=""]');
            $('#home-shortcode-output').text('[roadmap_home]');
            
            // Set initial cards shortcode based on page type
            if (type === 'career') {
                $('#cards-shortcode-output').text('[roadmap_cards type="career"]');
            } else if (type === 'certification') {
                $('#cards-shortcode-output').text('[roadmap_cards type="certification"]');
            } else {
                $('#cards-shortcode-output').text('[roadmap_cards type="both"]');
            }
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        TCRShortcode.init();
    });

})(jQuery);