(function($) {
    'use strict';

    // Global state management
    window.TCRoadmap = {
        state: {
            activeTab: 'career',
            searchQuery: '',
            currentRoadmapId: null,
            selectedModuleIndex: 0
        },

        init: function() {
            console.log('=== TCRoadmap initializing ===');
            
            var roadmapId = $('body').data('roadmap-id');
            if (roadmapId) {
                this.state.currentRoadmapId = roadmapId;
                console.log('Roadmap ID:', roadmapId);
            }
            
            if (window.tcrModulesData) {
                console.log('Module data loaded:', window.tcrModulesData);
                window.tcrModulesData.forEach(function(module) {
                    if (module.subGoals) {
                        module.subGoals.forEach(function(sg) {
                            sg.isCompleted = sg.isCompleted || false;
                        });
                    }
                });
            } else {
                console.error('ERROR: No module data found!');
            }
            
            var urlParams = new URLSearchParams(window.location.search);
            var tabParam = urlParams.get('tab');
            if (tabParam) {
                this.setActiveTab(tabParam);
            }
            this.bindEvents();
            
            var self = this;
            setTimeout(function() {
                self.loadProgress();
            }, 500);
        },

        bindEvents: function() {
            var self = this;
            console.log('=== Binding events ===');

            // Tab switching
            $(document).on('click', '.tcr-tab-button', function(e) {
                e.preventDefault();
                self.setActiveTab($(this).data('tab'));
            });

            // Search
            $(document).on('input', '.tcr-search-input', function() {
                self.state.searchQuery = $(this).val().toLowerCase();
                self.filterCards();
            });

            // Module selection
            $(document).on('click', '.tcr-select-module', function(e) {
                e.preventDefault();
                var index = parseInt($(this).data('module-index'));
                console.log('>>> Module clicked:', index);
                self.selectModule(index);
            });

            // Checkbox change - THE CRITICAL ONE
            $(document).on('change', '.tcr-subgoal-checkbox', function() {
                console.log('>>> Checkbox changed:', $(this).attr('id'), 'checked:', $(this).is(':checked'));

                // 1. Sync the *one* clicked checkbox to the global data model
                var $checkbox = $(this);
                var moduleIndex = parseInt($checkbox.data('module'));
                var subgoalIndex = parseInt($checkbox.data('subgoal'));
                var isChecked = $checkbox.is(':checked');

                if (window.tcrModulesData && 
                    window.tcrModulesData[moduleIndex] && 
                    window.tcrModulesData[moduleIndex].subGoals &&
                    window.tcrModulesData[moduleIndex].subGoals[subgoalIndex]) {

                    window.tcrModulesData[moduleIndex].subGoals[subgoalIndex].isCompleted = isChecked;
                }

                // 2. Update the progress UI and save to the backend
                self.updateProgress();
                self.saveProgress();

                // Remove the redundant setTimeout block
            });

            // Mark complete
            $(document).on('click', '.tcr-mark-complete', function(e) {
                e.preventDefault();
                console.log('>>> Mark complete clicked');
                self.markModuleAsComplete();
            });

            // Previous button
            $(document).on('click', '.tcr-prev-module', function(e) {
                e.preventDefault();
                console.log('>>> Previous clicked');
                if (!$(this).prop('disabled')) {
                    self.selectModule(self.state.selectedModuleIndex - 1);
                }
            });

            // Next button
            $(document).on('click', '.tcr-next-module', function(e) {
                e.preventDefault();
                console.log('>>> Next clicked, current:', self.state.selectedModuleIndex);
                if (!$(this).prop('disabled')) {
                    self.selectModule(self.state.selectedModuleIndex + 1);
                }
            });
            
            console.log('Events bound successfully');
        },

        setActiveTab: function(tab) {
            this.state.activeTab = tab;
            $('.tcr-tab-button').removeClass('active');
            $('.tcr-tab-button[data-tab="' + tab + '"]').addClass('active');
            $('.tcr-tab-content').hide();
            $('.tcr-tab-content[data-tab="' + tab + '"]').show();
        },

        filterCards: function() {
            var query = this.state.searchQuery;
            $('.card').each(function() {
                var title = $(this).find('h3').text().toLowerCase();
                var description = $(this).find('p').text().toLowerCase();
                if (title.includes(query) || description.includes(query)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
            
            if ($('.card:visible').length === 0 && query !== '') {
                $('.tcr-empty-state').show();
            } else {
                $('.tcr-empty-state').hide();
            }
        },

        selectModule: function(index) {
            console.log('=== selectModule called ===');
            console.log('Index:', index);
            console.log('Total modules:', window.tcrTotalModules);
            
            if (index < 0 || index >= window.tcrTotalModules) {
                console.log('Index out of range!');
                return;
            }

            // Sync current checkboxes before switching
            this.saveProgress();
            
            var completed = 0;
            
            this.state.selectedModuleIndex = index;
            
            // Update sidebar
            $('.roadmap-step').removeClass('active');
            $('.roadmap-step[data-module-index="' + index + '"]').addClass('active');
            $('.tcr-module-button').removeClass('active');
            $('.tcr-module-button[data-module-index="' + index + '"]').addClass('active');
            
            // Render new module
            if (typeof window.renderModuleContent === 'function') {
                console.log('Calling renderModuleContent...');
                window.renderModuleContent(index);
            } else {
                console.error('ERROR: renderModuleContent not found!');
            }
            
            // Update UI
            var self = this;
            setTimeout(function() {
                self.updateProgress();
            }, 100);
            
            $('.roadmap-main-content').animate({ scrollTop: 0 }, 300);
        },

        markModuleAsComplete: function() {
            if (!window.tcrModulesData) return;
            
            var module = window.tcrModulesData[this.state.selectedModuleIndex];
            if (!module || !module.subGoals) return;
            
            var isComplete = module.subGoals.every(function(sg) { return sg.isCompleted; });
            var newState = !isComplete;
            
            console.log('Setting all subgoals to:', newState);
            
            module.subGoals.forEach(function(subGoal) {
                subGoal.isCompleted = newState;
            });
            
            // Update visible checkboxes
            $('.tcr-subgoal-checkbox').each(function() {
                $(this).prop('checked', newState);
            });
            
            this.updateProgress();
            this.saveProgress();
        },

        // NEW: Sync checkbox DOM state to module data
        syncCheckboxesToData: function() {
            console.log('=== Syncing checkboxes to data ===');
            
            if (!window.tcrModulesData) return;
            
            var self = this;
            var synced = 0;
            
            // Find ALL checkboxes on the page
            $('.tcr-subgoal-checkbox').each(function() {
                var $checkbox = $(this);
                var id = $checkbox.attr('id');
                var isChecked = $checkbox.is(':checked');
                var moduleIndex = parseInt($checkbox.data('module'));
                var subgoalIndex = parseInt($checkbox.data('subgoal'));
                
                console.log('Syncing:', id, 'checked:', isChecked, 'module:', moduleIndex, 'subgoal:', subgoalIndex);
                
                if (window.tcrModulesData[moduleIndex] && 
                    window.tcrModulesData[moduleIndex].subGoals &&
                    window.tcrModulesData[moduleIndex].subGoals[subgoalIndex]) {
                    
                    window.tcrModulesData[moduleIndex].subGoals[subgoalIndex].isCompleted = isChecked;
                    synced++;
                }
            });
            
            console.log('Synced', synced, 'checkboxes');
        },

        updateProgress: function() {
            console.log('=== updateProgress called ===');
            
            if (!window.tcrModulesData) {
                console.error('No module data!');
                return;
            }
            
           
            // Count totals
            var completed = 0;
            var total = 0;
            
            window.tcrModulesData.forEach(function(module) {
                if (module.subGoals) {
                    module.subGoals.forEach(function(sg) {
                        total++;
                        if (sg.isCompleted) completed++;
                    });
                }
            });
            
            var percent = total > 0 ? Math.round((completed / total) * 100) : 0;
            console.log('Progress:', completed, '/', total, '=', percent + '%');
            
            window.tcrModulesData.forEach(function(module, mIdx) {
            var isModuleCompleted = module.subGoals && module.subGoals.length > 0 && 
                module.subGoals.every(function(sg) { return sg.isCompleted; });
            var $dot = $('.roadmap-step[data-module-index="' + mIdx + '"]').find('.roadmap-dot');

            // Reset classes
            $dot.removeClass('completed active bg-gray-400');

            // Apply new classes
            if (isModuleCompleted) {
                $dot.addClass('completed');
            } else if (mIdx === TCRoadmap.state.selectedModuleIndex) {
                $dot.addClass('active');
            } else {
                $dot.addClass('bg-gray-400');
            }
        });
            
            // Update ALL progress bars and text
            $('#tcr-progress-bar, .tcr-progress-bar').css('width', percent + '%').attr('aria-valuenow', percent);
            $('#tcr-progress-text, .tcr-progress-text').text(percent + '% complete (' + completed + '/' + total + ' steps)');
            
            // Update current module stats
            var currentModule = window.tcrModulesData[this.state.selectedModuleIndex];
            if (currentModule && currentModule.subGoals) {
                var currentTotal = currentModule.subGoals.length;
                var currentCompleted = currentModule.subGoals.filter(function(sg) { return sg.isCompleted; }).length;
                
                $('.tcr-module-completion').text(currentCompleted + '/' + currentTotal + ' milestones completed');
                
                var $markBtn = $('.tcr-mark-complete');
                if (currentCompleted === currentTotal && currentTotal > 0) {
                    $markBtn.html('<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width: 1rem; height: 1rem;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> Completed');
                    $markBtn.css('background-color', '#9ca3af');
                } else {
                    $markBtn.html('<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width: 1rem; height: 1rem;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> Mark Complete');
                    $markBtn.css('background-color', '#60a5fa');
                }
            }
            
            // Update nav buttons
            $('.tcr-prev-module').prop('disabled', this.state.selectedModuleIndex === 0);
            $('.tcr-next-module').prop('disabled', this.state.selectedModuleIndex === window.tcrTotalModules - 1);
            
            console.log('Progress update complete');
        },

        renderLeftPanelContent: function() {
            if (!window.tcrModulesData) return '';
            
            var self = this;
            var learningPath = window.tcrModulesData;
            
            var globalCompleted = 0;
            var globalTotal = 0;
            learningPath.forEach(function(module) {
                if (module.subGoals) {
                    module.subGoals.forEach(function(sg) {
                        globalTotal++;
                        if (sg.isCompleted) globalCompleted++;
                    });
                }
            });
            var globalPercent = globalTotal > 0 ? Math.round((globalCompleted / globalTotal) * 100) : 0;
            
            var listItems = learningPath.map(function(module, mIdx) {
                var isActive = self.state.selectedModuleIndex === mIdx;
                var isModuleCompleted = module.subGoals && module.subGoals.length > 0 && 
                    module.subGoals.every(function(sg) { return sg.isCompleted; });
                var dotClass = isModuleCompleted ? 'completed' : (isActive ? 'active' : 'bg-gray-400');
                
                return '<div class="roadmap-step" data-module-index="' + mIdx + '">' +
                    '<div class="roadmap-dot ' + dotClass + '"></div>' +
                    '<button class="tcr-select-module tcr-module-button ' + (isActive ? 'active' : '') + '" data-module-index="' + mIdx + '" ' +
                    'style="width: 100%; text-align: left; padding: 0.75rem; border-radius: 0.5rem; border: 1px solid transparent; ' +
                    'background: ' + (isActive ? '#eff6ff' : 'transparent') + '; transition: all 0.2s ease; cursor: pointer; ' +
                    (isActive ? 'border-color: #bfdbfe; box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);' : '') + '">' +
                    '<span class="text-xs" style="font-size: 0.75rem; font-weight: 600; color: #6b7280;">Step ' + (mIdx + 1) + ' of ' + learningPath.length + '</span>' +
                    '<h4 class="text-base" style="font-size: 1rem; font-weight: 700; color: #1f2937; margin-bottom: 0.25rem;">' + module.title + '</h4>' +
                    '<p class="text-sm" style="font-size: 0.875rem; color: #4b5563;">' + (module.shortDesc || 'Click to view details.') + '</p>' +
                    '</button></div>';
            }).join('');
            
            var backUrl = window.location.href.split('/').slice(0, -2).join('/') + '/';
            
            return '<div style="padding-top: 2.5rem;">' +
                '<a href="' + backUrl + '" class="tcr-back-button" style="display: flex; align-items: center; gap: 0.25rem; margin-bottom: 2rem; color: #60a5fa; text-decoration: none; font-weight: 500;">' +
                '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width: 1rem; height: 1rem;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>' +
                'Back to Roadmaps</a>' +
                '<h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1rem; color: #1f2937;">Learning Path</h2>' +
                '<div style="margin-bottom: 1.5rem;">' +
                '<div style="display: flex; justify-content: space-between; font-size: 0.875rem; font-weight: 500; color: #4b5563; margin-bottom: 0.5rem;">' +
                '<span>Progress</span>' +
                '<span id="tcr-progress-text" class="tcr-progress-text" style="color: #33A1E0; font-weight: 600;">' +
                globalPercent + '% complete (' + globalCompleted + '/' + globalTotal + ' steps)</span>' +
                '</div>' +
                '<div style="width: 100%; background-color: #e5e7eb; border-radius: 9999px; height: 0.5rem;">' +
                '<div id="tcr-progress-bar" style="background: linear-gradient(to right, #60a5fa, #a855f7); height: 100%; border-radius: 9999px; width: ' + globalPercent + '%; transition: width 0.7s ease;" role="progressbar" aria-valuenow="' + globalPercent + '" aria-valuemin="0" aria-valuemax="100"></div>' +
                '</div></div>' +
                '<div style="display: flex; flex-direction: column; gap: 0.5rem;">' + listItems + '</div>' +
                '</div>';
        },

        saveProgress: function() {
            var roadmapId = this.state.currentRoadmapId;
            if (!roadmapId || !window.tcrModulesData) return;

            var progress = {};
            
            window.tcrModulesData.forEach(function(module, mIdx) {
                if (!module.subGoals) return;
                module.subGoals.forEach(function(sg, sgIdx) {
                    // Use data attributes as key
                    var key = 'module-' + mIdx + '-subgoal-' + sgIdx;
                    progress[key] = sg.isCompleted || false;
                });
            });

            console.log('Saving progress:', progress);

            $.ajax({
                url: tcrAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'save_roadmap_progress',
                    nonce: tcrAjax.nonce,
                    roadmap_id: roadmapId,
                    progress: JSON.stringify(progress)
                },
                success: function(response) {
                    console.log('Progress saved!', response);
                },
                error: function(xhr, status, error) {
                    console.error('Save error:', error);
                }
            });
        },

        loadProgress: function() {
            var roadmapId = this.state.currentRoadmapId;
            if (!roadmapId || !window.tcrModulesData) return;

            var self = this;
            console.log('Loading progress...');
            
            $.ajax({
                url: tcrAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'get_roadmap_progress',
                    nonce: tcrAjax.nonce,
                    roadmap_id: roadmapId
                },
                success: function(response) {
                    console.log('Progress response:', response);
                    
                    if (response.success && response.data) {
                        var progress = response.data;
                        
                        // Apply to module data using data attributes
                        window.tcrModulesData.forEach(function(module, mIdx) {
                            if (!module.subGoals) return;
                            module.subGoals.forEach(function(sg, sgIdx) {
                                var key = 'module-' + mIdx + '-subgoal-' + sgIdx;
                                if (progress[key] !== undefined) {
                                    sg.isCompleted = progress[key];
                                }
                            });
                        });
                        
                        // Apply to visible checkboxes
                        $('.tcr-subgoal-checkbox').each(function() {
                            var mIdx = $(this).data('module');
                            var sgIdx = $(this).data('subgoal');
                            if (window.tcrModulesData[mIdx] && window.tcrModulesData[mIdx].subGoals[sgIdx]) {
                                $(this).prop('checked', window.tcrModulesData[mIdx].subGoals[sgIdx].isCompleted);
                            }
                        });
                        
                        self.updateProgress();
                        console.log('Progress loaded and applied!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Load error:', error);
                }
            });
        },

        createSlug: function(text) {
            if (!text) return '';
            return text.toString().toLowerCase()
                .replace(/\s+/g, '-')
                .replace(/[^\w\-]+/g, '')
                .replace(/\-\-+/g, '-')
                .replace(/^-+/, '')
                .replace(/-+$/, '');
        }
    };

    $(document).ready(function() {
        console.log('========== DOM READY ==========');
        window.TCRoadmap.init();
        
        if ($('.tcr-wrapper').length) {
            $('body').addClass('tcr-full-width-page');
            $('.tcr-wrapper').parents('.wp-block-group, .entry-content, .wp-block-post-content, main').each(function() {
                $(this).css({
                    'max-width': 'none',
                    'padding-left': '0',
                    'padding-right': '0',
                    'margin-left': '0',
                    'margin-right': '0'
                });
            });
        }
    });

})(jQuery);