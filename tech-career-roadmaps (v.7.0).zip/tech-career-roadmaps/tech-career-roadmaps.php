<?php
/**
 * Plugin Name: Tech Career Roadmaps
 * Plugin URI: https://TechCareerRoadmaps.com
 * Description: Interactive career and certification roadmaps with progress tracking
 * Version: 1.0.0
 * Author: Dearah Barsolasco
 * Author URI: https://dearahbarsolasco.com
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TCR_VERSION', '1.0.0');
define('TCR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TCR_PLUGIN_URL', plugin_dir_url(__FILE__));

class TechCareerRoadmaps {
    public function add_fullwidth_styles() {
    if (is_singular('career_roadmap') || is_singular('cert_roadmap')) {
        ?>
        <style>
            body .wp-site-blocks,
            body .wp-block-group,
            body main,
            body main.wp-block-group,
            body .entry-content,
            body .wp-block-post-content,
            body article {
                max-width: 100% !important;
                width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        </style>
        <?php
    }
}
    public function __construct() {
        add_action('wp_head', array($this, 'add_fullwidth_styles'));
        add_shortcode('career_roadmap', array($this, 'career_roadmap_shortcode'));
        add_shortcode('certification_roadmap', array($this, 'certification_roadmap_shortcode'));
        add_shortcode('roadmap_home', array($this, 'roadmap_home_shortcode'));
        add_shortcode('roadmap_cards', array($this, 'roadmap_cards_shortcode'));
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        
        add_action('init', array($this, 'register_post_types'));
        
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_roadmap_meta'));
        
        add_action('wp_ajax_save_roadmap_progress', array($this, 'save_progress'));
        add_action('wp_ajax_nopriv_save_roadmap_progress', array($this, 'save_progress'));
        add_action('wp_ajax_get_roadmap_progress', array($this, 'get_progress'));
        add_action('wp_ajax_nopriv_get_roadmap_progress', array($this, 'get_progress'));
        
        add_filter('template_include', array($this, 'load_custom_template'));

        add_action('admin_menu', array($this, 'add_shortcode_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_shortcode_admin_assets'));
        add_action('wp_ajax_tcr_get_roadmap_preview', array($this, 'ajax_get_roadmap_preview'));
        
        add_action('admin_enqueue_scripts', array($this, 'enqueue_learning_path_editor'));

        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_layout_css'));
        
        add_shortcode('td_roadmap', array($this, 'dynamic_roadmap_shortcode'));

    }
    
    public function enqueue_admin_layout_css($hook) {
        $screen = get_current_screen();
        
        if (is_object($screen) && ($screen->post_type === 'career_roadmap' || $screen->post_type === 'cert_roadmap') && ($hook === 'post.php' || $hook === 'post-new.php')) {
            wp_enqueue_style('tcr-admin-layout', TCR_PLUGIN_URL . 'assets/tcr-admin-layout.css', array(), TCR_VERSION);
        }
    }
    
    public function enqueue_learning_path_editor($hook) {
        $screen = get_current_screen();
        if (!is_object($screen) || ($screen->post_type !== 'career_roadmap' && $screen->post_type !== 'cert_roadmap')) {
            return;
        }

        if ($hook === 'post.php' || $hook === 'post-new.php') {
            wp_enqueue_script('jquery-ui-sortable');
            wp_enqueue_script('tcr-learning-path-editor', TCR_PLUGIN_URL . 'assets/learning-path-editor.js', array('jquery'), TCR_VERSION, true);
        }
    }
    

   public function add_shortcode_menu() {
    // Add ShortCodes submenu under Career Roadmaps
    add_submenu_page(
        'edit.php?post_type=career_roadmap',
        'ShortCodes',
        'ShortCodes',
        'manage_options',
        'tcr-shortcodes',
        function() {
            $this->render_shortcode_page('career');
        }
    );
    
    // Add ShortCodes submenu under Certification Roadmaps
    add_submenu_page(
        'edit.php?post_type=cert_roadmap',
        'ShortCodes',
        'ShortCodes',
        'manage_options',
        'tcr-shortcodes-cert',
        function() {
            $this->render_shortcode_page('certification');
        }
    );
}

public function enqueue_shortcode_admin_assets($hook) {
    if ($hook !== 'career_roadmap_page_tcr-shortcodes' && $hook !== 'cert_roadmap_page_tcr-shortcodes-cert') {
        return;
    }
    
    // Determine page type based on hook
    $page_type = ($hook === 'career_roadmap_page_tcr-shortcodes') ? 'career' : 'certification';
    
    wp_enqueue_style('tcr-shortcode-admin', TCR_PLUGIN_URL . 'assets/shortcode-admin.css', array(), TCR_VERSION);
    wp_enqueue_script('tcr-shortcode-admin', TCR_PLUGIN_URL . 'assets/shortcode-admin.js', array('jquery'), TCR_VERSION, true);
    
    wp_localize_script('tcr-shortcode-admin', 'tcrShortcode', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('tcr_shortcode_nonce'),
        'careerRoadmaps' => $this->get_roadmaps_for_select('career_roadmap'),
        'certRoadmaps' => $this->get_roadmaps_for_select('cert_roadmap'),
        'pageType' => $page_type // Add this line
    ));
}

private function get_roadmaps_for_select($post_type) {
    $roadmaps = get_posts(array(
        'post_type' => $post_type,
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'orderby' => 'title',
        'order' => 'ASC'
    ));
    
    $options = array();
    foreach ($roadmaps as $roadmap) {
        $options[] = array(
            'id' => $roadmap->ID,
            'title' => $roadmap->post_title
        );
    }
    
    return $options;
}

public function render_shortcode_page($context = 'both') {
    ?>
     <div class="wrap tcr-shortcode-wrap">
        <h1 class="wp-heading-inline">
            <span class="dashicons dashicons-shortcode" style="font-size: 28px; margin-right: 8px;"></span>
            ShortCode Generator
        </h1>
        <p class="description">Generate shortcodes to embed roadmaps anywhere on your site</p>
        
        <div class="tcr-shortcode-container">
            <div class="tcr-shortcode-tabs">
                <?php if ($context === 'both' || $context === 'career'): ?>
                <button class="tcr-tab-btn active" data-tab="career">
                    <span class="dashicons dashicons-chart-line"></span>
                    Career Roadmap
                </button>
                <?php endif; ?>
                
                <?php if ($context === 'both' || $context === 'certification'): ?>
                <button class="tcr-tab-btn <?php echo ($context === 'certification') ? 'active' : ''; ?>" data-tab="certification">
                    <span class="dashicons dashicons-awards"></span>
                    Certification Roadmap
                </button>
                <?php endif; ?>
                
                <button class="tcr-tab-btn" data-tab="cards">
                    <span class="dashicons dashicons-grid-view"></span>
                    Roadmap Cards
                </button>
                <button class="tcr-tab-btn" data-tab="home">
                    <span class="dashicons dashicons-admin-home"></span>
                    Roadmap Home
                </button>
                <button class="tcr-tab-btn" data-tab="dynamic">
                    <span class="dashicons dashicons-admin-generic"></span>
                    Dynamic Creator
                </button>
            </div>
            
            <!-- CAREER TAB - Only show if context allows -->
            <?php if ($context === 'both' || $context === 'career'): ?>
            <div class="tcr-tab-content <?php echo ($context === 'career') ? 'active' : 'active'; ?>" id="career-tab">
                <div class="tcr-shortcode-builder">
                    <div class="tcr-builder-section">
                        <h2>Select Career Roadmap</h2>
                        <div class="tcr-form-group">
                            <label for="career-select">Choose a roadmap:</label>
                            <select id="career-select" class="tcr-select">
                                <option value="">-- Select Career Roadmap --</option>
                                <?php
                                $career_roadmaps = get_posts(array(
                                    'post_type' => 'career_roadmap',
                                    'posts_per_page' => -1,
                                    'post_status' => 'publish',
                                    'orderby' => 'title',
                                    'order' => 'ASC'
                                ));
                                
                                foreach ($career_roadmaps as $roadmap) {
                                    echo '<option value="' . esc_attr($roadmap->ID) . '">' . esc_html($roadmap->post_title) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="tcr-preview-section">
                            <h3>Roadmap Preview</h3>
                            <div id="career-preview" class="tcr-roadmap-preview">
                                 <p class="tcr-no-selection">Select a roadmap to see preview</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tcr-output-section">
                        <h3>Generated ShortCode</h3>
                        <div class="tcr-shortcode-output">
                            <code id="career-shortcode-output">[career_roadmap id=""]</code>
                            <button class="button button-primary tcr-copy-btn" data-target="career-shortcode-output">
                               Copy
                            </button>
                        </div>
                        
                        <div class="tcr-usage-info">
                            <h4><span class="dashicons dashicons-info"></span> How to Use</h4>
                            <ol>
                                <li>Select a career roadmap from the dropdown above</li>
                                <li>Copy the generated shortcode</li>
                                <li>Paste it into any page or post editor</li>
                                <li>Publish and view the embedded roadmap</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
			<?php endif; ?>
            
            <!-- EXISTING CERTIFICATION TAB -->
            <?php if ($context === 'both' || $context === 'certification'): ?>
			<div class="tcr-tab-content <?php echo ($context === 'certification') ? 'active' : ''; ?>" id="certification-tab">
                <div class="tcr-shortcode-builder">
                    <div class="tcr-builder-section">
                        <h2>Select Certification Roadmap</h2>
                        <div class="tcr-form-group">
                            <label for="cert-select">Choose a certification:</label>
                            <select id="cert-select" class="tcr-select">
                                <option value="">-- Select Certification --</option>
                                <?php
                                $cert_roadmaps = get_posts(array(
                                    'post_type' => 'cert_roadmap',
                                    'posts_per_page' => -1,
                                    'post_status' => 'publish',
                                    'orderby' => 'title',
                                    'order' => 'ASC'
                                ));
                                
                                foreach ($cert_roadmaps as $cert) {
                                    echo '<option value="' . esc_attr($cert->ID) . '">' . esc_html($cert->post_title) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="tcr-preview-section">
                            <h3>Certification Preview</h3>
                            <div id="cert-preview" class="tcr-roadmap-preview">
                                <p class="tcr-no-selection">Select a certification to see preview</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tcr-output-section">
                        <h3>Generated ShortCode</h3>
                        <div class="tcr-shortcode-output">
                            <code id="cert-shortcode-output">[certification_roadmap id=""]</code>
                            <button class="button button-primary tcr-copy-btn" data-target="cert-shortcode-output">
                               Copy
                            </button>
                        </div>
                        
                        <div class="tcr-usage-info">
                            <h4><span class="dashicons dashicons-info"></span> How to Use</h4>
                            <ol>
                                <li>Select a certification from the dropdown above</li>
                                <li>Copy the generated shortcode</li>
                                <li>Paste it into any page or post editor</li>
                                <li>Publish and view the embedded certification roadmap</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
			<?php endif; ?>
            
            <!-- NEW ROADMAP CARDS TAB -->
            <div class="tcr-tab-content" id="cards-tab">
                <div class="tcr-shortcode-builder">
                    <div class="tcr-builder-section">
                        <h2>Display Roadmap Cards Only</h2>
                        <p class="description">Show just the roadmap cards in a grid format without the full homepage layout. Perfect for embedding on any page!</p>
                        
                        <div class="tcr-form-group">
                            <label for="cards-type">Select Type:</label>
                            <select id="cards-type" class="tcr-select">
                                <option value="both">Both Career & Certifications</option>
                                <option value="career">Career Roadmaps Only</option>
                                <option value="certification">Certifications Only</option>
                            </select>
                        </div>
                        
                        <div class="tcr-form-group">
                            <label for="cards-limit">Number of Cards to Show:</label>
                            <select id="cards-limit" class="tcr-select">
                                <option value="-1">All Cards</option>
                                <option value="3">3 Cards</option>
                                <option value="6">6 Cards</option>
                                <option value="9">9 Cards</option>
                                <option value="12">12 Cards</option>
                            </select>
                        </div>
                        
                        <div class="tcr-form-group">
                            <label for="cards-ids">Specific IDs (Optional):</label>
                            <input type="text" id="cards-ids" class="tcr-select" placeholder="e.g., 93,95,102 (leave empty for all)">
                            <p class="description" style="margin-top: 8px; font-size: 12px; color: #666;">Enter comma-separated post IDs to show only specific roadmaps. Leave empty to show all.</p>
                        </div>
                        
                        <div class="tcr-preview-section">
                            <h3>Preview</h3>
                            <div id="cards-preview" class="tcr-roadmap-preview">
                                <div class="tcr-preview-card">
                                    <h4>Roadmap Cards Grid</h4>
                                    <p style="margin: 10px 0 0 0; opacity: 0.9;">This will display your selected roadmaps in a responsive grid layout with card elements like the homepage, but without the hero section, tabs, or footer.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tcr-output-section">
                        <h3>Generated ShortCode</h3>
                        <div class="tcr-shortcode-output">
                            <code id="cards-shortcode-output">[roadmap_cards type="both"]</code>
                            <button class="button button-primary tcr-copy-btn" data-target="cards-shortcode-output">
    Copy
                            </button>
                        </div>
                        
                        <div class="tcr-usage-info">
                            <h4><span class="dashicons dashicons-info"></span> How to Use</h4>
                            <ol>
                                <li>Select the type of roadmaps to display</li>
                                <li>Choose how many cards to show (or show all)</li>
                                <li>Optionally enter specific IDs</li>
                                <li>Copy the generated shortcode</li>
                                <li>Paste it into any page or post</li>
                            </ol>
                            <p><strong>Examples:</strong></p>
                            <ul style="margin: 10px 0 0 20px; font-size: 12px;">
                                <li><code>[roadmap_cards type="career" limit="6"]</code> - Show 6 career roadmaps</li>
                                <li><code>[roadmap_cards type="certification"]</code> - Show all certifications</li>
                                <li><code>[roadmap_cards type="both" ids="93,95,102"]</code> - Show specific roadmaps by ID</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- EXISTING HOME TAB -->
            <div class="tcr-tab-content" id="home-tab">
                <div class="tcr-shortcode-builder">
                    <div class="tcr-builder-section full-width">
                        <h2>Roadmap Home Page</h2>
                        <p class="description">This shortcode displays all your career and certification roadmaps in a beautiful grid layout with tabs.</p>
                    </div>
                    
                    <div class="tcr-output-section">
                        <h3>ShortCode</h3>
                        <div class="tcr-shortcode-output">
                            <code id="home-shortcode-output">[roadmap_home]</code>
                            <button class="button button-primary tcr-copy-btn" data-target="home-shortcode-output">
                       Copy
                            </button>
                        </div>
                        
                        <div class="tcr-usage-info">
                            <h4><span class="dashicons dashicons-info"></span> How to Use</h4>
                            <ol>
                                <li>Copy the <code>[roadmap_home]</code> shortcode above</li>
                                <li>Create a new page (e.g., "Tech Roadmaps" or "Certifications")</li>
                                <li>Paste the shortcode into the page content</li>
                                <li>Publish the page</li>
                            </ol>
                            <p><strong>Note:</strong> This shortcode automatically displays all published roadmaps organized by type with search functionality.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- NEW: DYNAMIC CREATOR TAB -->
            <div class="tcr-tab-content" id="dynamic-tab" style="display: none;">
                <div class="tcr-shortcode-builder">
                    <div class="tcr-builder-section full-width" style="max-width: 100%;">
                        <h2><span class="dashicons dashicons-admin-generic"></span> Dynamic Roadmap Creator</h2>
                        <p class="description">Create or update roadmaps directly using shortcodes. Fill in the form below and copy the generated shortcode.</p>
                        
                        <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin-bottom: 20px; border-radius: 4px;">
                            <strong>⚠️ Important:</strong> You must be logged in as an Editor or Administrator to use create/update actions.
                        </div>

                        <form id="dynamic-roadmap-form" style="background: #f9fafb; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                <!-- Left Column -->
                                <div>
                                    <h3 style="margin-top: 0; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Basic Information</h3>
                                    
                                    <div class="tcr-form-group">
                                        <label for="dyn-action"><strong>Action</strong></label>
                                        <select id="dyn-action" class="tcr-select">
                                            <option value="create">Create New Roadmap</option>
                                            <option value="update">Update Existing Roadmap</option>
                                        </select>
                                    </div>

                                    <div class="tcr-form-group" id="dyn-id-group" style="display: none;">
                                        <label for="dyn-id"><strong>Roadmap ID (for update)</strong></label>
                                        <input type="number" id="dyn-id" class="tcr-select" placeholder="e.g., 74">
                                        <p class="description">Find the ID in the Career Roadmaps or Certification Roadmaps list</p>
                                    </div>

                                    <div class="tcr-form-group">
                                        <label for="dyn-type"><strong>Roadmap Type</strong></label>
                                        <select id="dyn-type" class="tcr-select">
                                            <option value="career">Career Roadmap</option>
                                            <option value="certification">Certification</option>
                                        </select>
                                    </div>

                                    <div class="tcr-form-group">
                                        <label for="dyn-title"><strong>Title</strong></label>
                                        <input type="text" id="dyn-title" class="tcr-select" placeholder="e.g., DevOps Engineer">
                                    </div>

                                    <div class="tcr-form-group">
                                        <label for="dyn-description"><strong>Description</strong></label>
                                        <textarea id="dyn-description" class="tcr-select" rows="3" placeholder="Full description of the roadmap"></textarea>
                                    </div>

                                    <div class="tcr-form-group">
                                        <label for="dyn-short-desc"><strong>Short Description</strong></label>
                                        <input type="text" id="dyn-short-desc" class="tcr-select" placeholder="Brief description (50 chars max)" maxlength="100">
                                    </div>

                                    <div class="tcr-form-group">
                                        <label for="dyn-icon"><strong>Icon (Emoji)</strong></label>
                                        <input type="text" id="dyn-icon" class="tcr-select" placeholder="⚙️">
                                    </div>

                                    <div class="tcr-form-group">
                                        <label for="dyn-color"><strong>Gradient Colors</strong></label>
                                        <input type="text" id="dyn-color" class="tcr-select" placeholder="#3b82f6, #8b5cf6">
                                        <p class="description">Two hex colors separated by comma</p>
                                    </div>
                                </div>

                                <!-- Right Column -->
                                <div>
                                    <h3 style="margin-top: 0; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">Type-Specific Details</h3>
                                    
                                    <!-- Career Fields -->
                                    <div id="career-fields">
                                        <div class="tcr-form-group">
                                            <label for="dyn-salary"><strong>Average Salary</strong></label>
                                            <input type="text" id="dyn-salary" class="tcr-select" placeholder="$90k-140k">
                                        </div>

                                        <div class="tcr-form-group">
                                            <label for="dyn-duration"><strong>Duration</strong></label>
                                            <input type="text" id="dyn-duration" class="tcr-select" placeholder="8-12 months">
                                        </div>

                                        <div class="tcr-form-group">
                                            <label for="dyn-level"><strong>Experience Level</strong></label>
                                            <select id="dyn-level" class="tcr-select">
                                                <option value="Beginner">Beginner</option>
                                                <option value="Intermediate">Intermediate</option>
                                                <option value="Advanced">Advanced</option>
                                            </select>
                                        </div>

                                        <div class="tcr-form-group">
                                            <label for="dyn-skills"><strong>Key Skills (comma-separated)</strong></label>
                                            <textarea id="dyn-skills" class="tcr-select" rows="3" placeholder="Docker, Kubernetes, CI/CD, AWS"></textarea>
                                        </div>
                                    </div>

                                    <!-- Certification Fields -->
                                    <div id="cert-fields" style="display: none;">
                                        <div class="tcr-form-group">
                                            <label for="dyn-provider"><strong>Provider</strong></label>
                                            <input type="text" id="dyn-provider" class="tcr-select" placeholder="AWS">
                                        </div>

                                        <div class="tcr-form-group">
                                            <label for="dyn-cert-level"><strong>Certification Level</strong></label>
                                            <select id="dyn-cert-level" class="tcr-select">
                                                <option value="Foundational">Foundational</option>
                                                <option value="Associate">Associate</option>
                                                <option value="Professional">Professional</option>
                                                <option value="Expert">Expert</option>
                                            </select>
                                        </div>

                                        <div class="tcr-form-group">
                                            <label for="dyn-exam-cost"><strong>Exam Cost</strong></label>
                                            <input type="text" id="dyn-exam-cost" class="tcr-select" placeholder="$150">
                                        </div>

                                        <div class="tcr-form-group">
                                            <label for="dyn-estimated-time"><strong>Estimated Study Time</strong></label>
                                            <input type="text" id="dyn-estimated-time" class="tcr-select" placeholder="40-60 hours">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div style="margin-top: 20px; padding-top: 20px; border-top: 2px solid #e5e7eb;">
                                <button type="button" id="generate-dynamic-shortcode" class="button button-primary button-hero">
                                    <span class="dashicons dashicons-admin-generic"></span> Generate ShortCode
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <div class="tcr-output-section" style="margin-top: 30px;">
                        <h3>Generated ShortCode</h3>
                        <div class="tcr-shortcode-output">
                            <code id="dynamic-shortcode-output" style="font-size: 12px; word-break: break-all;">[td_roadmap]</code>
                            <button class="button button-primary tcr-copy-btn" data-target="dynamic-shortcode-output">
                                Copy
                            </button>
                        </div>
                        
                        <div class="tcr-usage-info">
                            <h4><span class="dashicons dashicons-info"></span> How to Use</h4>
                            <ol>
                                <li>Fill in the form above with your roadmap details</li>
                                <li>Click "Generate ShortCode" to create the shortcode</li>
                                <li>Copy the generated shortcode</li>
                                <li>Paste it into any page or post editor</li>
                                <li>Publish the page - the roadmap will be created/updated automatically!</li>
                            </ol>
                            <p><strong>Note:</strong> For update actions, you need to provide the roadmap ID. You can find this in the roadmap list (hover over the title to see the ID in the URL).</p>
                        </div>
                    </div>
                </div>
            </div>
            
           <div class="tcr-quick-reference">
    <h2><span class="dashicons dashicons-book"></span> Quick Reference</h2>
    <div class="tcr-reference-grid">
        <?php if ($context === 'both' || $context === 'career'): ?>
        <div class="tcr-reference-card">
            <h3>Career Roadmap</h3>
            <code>[career_roadmap id="123"]</code>
            <p>Embeds a single career roadmap</p>
        </div>
        <?php endif; ?>
        
        <?php if ($context === 'both' || $context === 'certification'): ?>
        <div class="tcr-reference-card">
            <h3>Certification</h3>
            <code>[certification_roadmap id="456"]</code>
            <p>Embeds a certification roadmap</p>
        </div>
        <?php endif; ?>
        
        <div class="tcr-reference-card">
            <h3>Roadmap Cards</h3>
            <code>[roadmap_cards type="<?php echo esc_attr($context === 'both' ? 'both' : $context); ?>"]</code>
            <p>Displays roadmap cards in grid</p>
        </div>
        
        <div class="tcr-reference-card">
            <h3>Home Page</h3>
            <code>[roadmap_home]</code>
            <p>Displays all roadmaps with tabs</p>
        </div>

        <div class="tcr-reference-card">
            <h3>Dynamic Creator</h3>
            <code>[td_roadmap action="create" ...]</code>
            <p>Create/update roadmaps via shortcode</p>
        </div>
    </div>
</div>
        
        <div id="tcr-toast" class="tcr-toast">
            <span class="dashicons dashicons-yes-alt"></span>
            ShortCode copied to clipboard!
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Show/hide ID field based on action
        $('#dyn-action').on('change', function() {
            if ($(this).val() === 'update') {
                $('#dyn-id-group').show();
            } else {
                $('#dyn-id-group').hide();
            }
        });

        // Show/hide fields based on type
        $('#dyn-type').on('change', function() {
            if ($(this).val() === 'certification') {
                $('#career-fields').hide();
                $('#cert-fields').show();
            } else {
                $('#career-fields').show();
                $('#cert-fields').hide();
            }
        });

        // Generate dynamic shortcode
        $('#generate-dynamic-shortcode').on('click', function() {
            var shortcode = '[td_roadmap';
            
            var action = $('#dyn-action').val();
            var id = $('#dyn-id').val();
            var type = $('#dyn-type').val();
            var title = $('#dyn-title').val();
            var description = $('#dyn-description').val();
            var shortDesc = $('#dyn-short-desc').val();
            var icon = $('#dyn-icon').val();
            var color = $('#dyn-color').val();
            
            shortcode += ' action="' + action + '"';
            
            if (action === 'update' && id) {
                shortcode += ' id="' + id + '"';
            }
            
            shortcode += ' type="' + type + '"';
            
            if (title) shortcode += ' title="' + title + '"';
            if (description) shortcode += ' description="' + description.replace(/"/g, '&quot;') + '"';
            if (shortDesc) shortcode += ' short_description="' + shortDesc + '"';
            if (icon) shortcode += ' icon="' + icon + '"';
            if (color) shortcode += ' color="' + color + '"';
            
            if (type === 'career') {
                var salary = $('#dyn-salary').val();
                var duration = $('#dyn-duration').val();
                var level = $('#dyn-level').val();
                var skills = $('#dyn-skills').val();
                
                if (salary) shortcode += ' salary="' + salary + '"';
                if (duration) shortcode += ' duration="' + duration + '"';
                if (level) shortcode += ' level="' + level + '"';
                if (skills) shortcode += ' skills="' + skills + '"';
            } else {
                var provider = $('#dyn-provider').val();
                var certLevel = $('#dyn-cert-level').val();
                var examCost = $('#dyn-exam-cost').val();
                var estimatedTime = $('#dyn-estimated-time').val();
                
                if (provider) shortcode += ' provider="' + provider + '"';
                if (certLevel) shortcode += ' level="' + certLevel + '"';
                if (examCost) shortcode += ' exam_cost="' + examCost + '"';
                if (estimatedTime) shortcode += ' estimated_time="' + estimatedTime + '"';
            }
            
            shortcode += ']';
            
            $('#dynamic-shortcode-output').text(shortcode);
        });
    });
    </script>
    <?php
}

public function ajax_get_roadmap_preview() {
    check_ajax_referer('tcr_shortcode_nonce', 'nonce');
    
    $post_id = intval($_POST['post_id']);
    $post_type = sanitize_text_field($_POST['post_type']);
    
    if (!$post_id || !in_array($post_type, array('career_roadmap', 'cert_roadmap'))) {
        wp_send_json_error('Invalid post ID or type');
    }
    
    $post = get_post($post_id);
    
    if (!$post || $post->post_type !== $post_type) {
        wp_send_json_error('Post not found');
    }
    
    $data = array(
        'title' => $post->post_title,
        'icon' => get_post_meta($post_id, '_tcr_icon', true),
        'color' => get_post_meta($post_id, '_tcr_color', true)
    );
    
    if ($post_type === 'career_roadmap') {
        $data['avgSalary'] = get_post_meta($post_id, '_tcr_avg_salary', true);
        $data['duration'] = get_post_meta($post_id, '_tcr_duration', true);
        $data['experienceLevel'] = get_post_meta($post_id, '_tcr_experience_level', true);
    } else {
        $data['provider'] = get_post_meta($post_id, '_tcr_provider', true);
        $data['level'] = get_post_meta($post_id, '_tcr_level', true);
        $data['examCost'] = get_post_meta($post_id, '_tcr_exam_cost', true);
    }
    
    wp_send_json_success($data);
}

public function load_custom_template($template) {
    if (is_singular('career_roadmap') || is_singular('cert_roadmap')) {
        $new_template = TCR_PLUGIN_DIR . 'templates/roadmap-single.php';
        if (file_exists($new_template)) {
            return $new_template;
        }
    }
    return $template;
}
    
public function register_post_types() {
    register_post_type('career_roadmap', array(
        'labels' => array(
            'name' => 'Career Roadmaps',
            'singular_name' => 'Career Roadmap',
            'add_new' => 'Add New Career Roadmap',
            'add_new_item' => 'Add New Career Roadmap',
            'edit_item' => 'Edit Career Roadmap',
            'view_item' => 'View Career Roadmap',
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-chart-line',
        'show_in_rest' => true,
    ));
    
    register_post_type('cert_roadmap', array(
        'labels' => array(
            'name' => 'Certification Roadmaps',
            'singular_name' => 'Certification Roadmap',
            'add_new' => 'Add New Certification',
            'add_new_item' => 'Add New Certification',
            'edit_item' => 'Edit Certification',
            'view_item' => 'View Certification',
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-awards',
        'show_in_rest' => true,
    ));
}
    
public function add_meta_boxes() {
    add_meta_box(
        'career_roadmap_details',
        'Career Details',
        array($this, 'career_meta_box_callback'),
        'career_roadmap',
        'normal',
        'high'
    );
    
    add_meta_box(
        'cert_roadmap_details',
        'Certification Details',
        array($this, 'cert_meta_box_callback'),
        'cert_roadmap',
        'normal',
        'high'
    );
    
    add_meta_box(
        'roadmap_learning_path',
        'Learning Path / Modules',
        array($this, 'learning_path_meta_box_callback'),
        array('career_roadmap', 'cert_roadmap'),
        'normal',
        'high'
    );
}
    
public function career_meta_box_callback($post) {
    wp_nonce_field('career_roadmap_meta_box', 'career_roadmap_meta_box_nonce');
    
    $icon = get_post_meta($post->ID, '_tcr_icon', true);
    $color = get_post_meta($post->ID, '_tcr_color', true);
    $avg_salary = get_post_meta($post->ID, '_tcr_avg_salary', true);
    $duration = get_post_meta($post->ID, '_tcr_duration', true);
    $experience_level = get_post_meta($post->ID, '_tcr_experience_level', true);
    $skills = get_post_meta($post->ID, '_tcr_skills', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="tcr_icon">Icon (Emoji)</label></th>
            <td><input type="text" id="tcr_icon" name="tcr_icon" value="<?php echo esc_attr($icon); ?>" class="regular-text" placeholder="💻"></td>
        </tr>
        <tr>
<th><label for="tcr_short_description">Short Description</label></th>
<td>
    <input type="text" id="tcr_short_description" name="tcr_short_description" value="<?php echo esc_attr(get_post_meta($post->ID, '_tcr_short_description', true)); ?>" class="regular-text" placeholder="Brief description (50 characters max)" maxlength="100">
    <p class="description">A brief description that appears on the homepage card (max 50 characters)</p>
</td>
</tr>
        <tr>
            <th><label for="tcr_color">Gradient Colors (hex codes)</label></th>
            <td>
                <input type="text" id="tcr_color" name="tcr_color" value="<?php echo esc_attr($color); ?>" class="regular-text" placeholder="#3b82f6, #8b5cf6">
                <p class="description">Enter two hex colors separated by comma (e.g., #3b82f6, #8b5cf6)</p>
            </td>
        </tr>
        <tr>
            <th><label for="tcr_avg_salary">Average Salary</label></th>
            <td><input type="text" id="tcr_avg_salary" name="tcr_avg_salary" value="<?php echo esc_attr($avg_salary); ?>" class="regular-text" placeholder="$80k-120k"></td>
        </tr>
        <tr>
            <th><label for="tcr_duration">Duration</label></th>
            <td><input type="text" id="tcr_duration" name="tcr_duration" value="<?php echo esc_attr($duration); ?>" class="regular-text" placeholder="6-12 months"></td>
        </tr>
        <tr>
            <th><label for="tcr_experience_level">Experience Level</label></th>
            <td>
                <select id="tcr_experience_level" name="tcr_experience_level">
                    <option value="Beginner" <?php selected($experience_level, 'Beginner'); ?>>Beginner</option>
                    <option value="Intermediate" <?php selected($experience_level, 'Intermediate'); ?>>Intermediate</option>
                    <option value="Advanced" <?php selected($experience_level, 'Advanced'); ?>>Advanced</option>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="tcr_skills">Key Skills (comma-separated)</label></th>
            <td><textarea id="tcr_skills" name="tcr_skills" rows="3" class="large-text"><?php echo esc_textarea($skills); ?></textarea></td>
        </tr>
    </table>
    <?php
}
    
public function cert_meta_box_callback($post) {
    wp_nonce_field('cert_roadmap_meta_box', 'cert_roadmap_meta_box_nonce');
    
    $icon = get_post_meta($post->ID, '_tcr_icon', true);
    $color = get_post_meta($post->ID, '_tcr_color', true);
    $provider = get_post_meta($post->ID, '_tcr_provider', true);
    $level = get_post_meta($post->ID, '_tcr_level', true);
    $exam_cost = get_post_meta($post->ID, '_tcr_exam_cost', true);
    $estimated_time = get_post_meta($post->ID, '_tcr_estimated_time', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="tcr_icon">Icon (Emoji)</label></th>
            <td><input type="text" id="tcr_icon" name="tcr_icon" value="<?php echo esc_attr($icon); ?>" class="regular-text" placeholder="🏆"></td>
        </tr>
        <tr>
            <th><label for="tcr_color">Gradient Colors (hex codes)</label></th>
            <td>
                <input type="text" id="tcr_color" name="tcr_color" value="<?php echo esc_attr($color); ?>" class="regular-text" placeholder="#3b82f6, #8b5cf6">
                <p class="description">Enter two hex colors separated by comma (e.g., #3b82f6, #8b5cf6)</p>
            </td>
        </tr>
        <tr>
            <th><label for="tcr_provider">Provider</label></th>
            <td><input type="text" id="tcr_provider" name="tcr_provider" value="<?php echo esc_attr($provider); ?>" class="regular-text" placeholder="AWS"></td>
        </tr>
        <tr>
            <th><label for="tcr_level">Level</label></th>
            <td>
                <select id="tcr_level" name="tcr_level">
                    <option value="Foundational" <?php selected($level, 'Foundational'); ?>>Foundational</option>
                    <option value="Associate" <?php selected($level, 'Associate'); ?>>Associate</option>
                    <option value="Professional" <?php selected($level, 'Professional'); ?>>Professional</option>
                    <option value="Expert" <?php selected($level, 'Expert'); ?>>Expert</option>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="tcr_exam_cost">Exam Cost</label></th>
            <td><input type="text" id="tcr_exam_cost" name="tcr_exam_cost" value="<?php echo esc_attr($exam_cost); ?>" class="regular-text" placeholder="$150"></td>
        </tr>
        <tr>
            <th><label for="tcr_estimated_time">Estimated Study Time</label></th>
            <td><input type="text" id="tcr_estimated_time" name="tcr_estimated_time" value="<?php echo esc_attr($estimated_time); ?>" class="regular-text" placeholder="40-60 hours"></td>
        </tr>
    </table>
    <?php
}
    
public function learning_path_meta_box_callback($post) {
    $learning_path_json = get_post_meta($post->ID, '_tcr_learning_path', true);
    
    ?>
    <div id="tcr-learning-path-container">
        <p><strong>Use the dynamic editor below to manage your modules:</strong></p>
        
        <div id="tcr-learning-path-editor-ui">
            <p>Loading editor...</p>
        </div>

        <p style="margin-top: 20px;">
            <button type="button" id="tcr-add-module" class="button button-primary">
                <span class="dashicons dashicons-plus"></span> Add New Module
            </button>
        </p>

        <h3 style="margin-top: 30px; border-bottom: 1px solid #ddd; padding-bottom: 5px;">Final JSON Output (Edit to mass-update modules)</h3>
        <p style="font-size: 12px; color: #666;">
            This field is updated by the editor. **You can paste a full JSON code here to overwrite and rebuild the modules above.**
        </p>
        <textarea 
            id="tcr_learning_path" 
            name="tcr_learning_path" 
            rows="8" 
            class="large-text code" 
            style="font-family: monospace; background-color: white; color: #333;" 
            ><?php echo esc_textarea($learning_path_json); ?></textarea>
        
        <p><button type="button" class="button" onclick="validateJSON()">Validate JSON</button> <span id="json-validation-message"></span></p>

        <script>
        window.tcrInitialLearningPathJSON = <?php echo json_encode($learning_path_json); ?>;
        function validateJSON() {
            var textarea = document.getElementById('tcr_learning_path');
            var message = document.getElementById('json-validation-message');
            try {
                JSON.parse(textarea.value);
                message.innerHTML = '<span style="color: green;">✓ Valid JSON</span>';
            } catch(e) {
                message.innerHTML = '<span style="color: red;">✗ Invalid JSON: ' + e.message + '</span>';
            }
        }
        </script>
    </div>
    <?php
}
    
public function save_roadmap_meta($post_id) {
    if (!isset($_POST['career_roadmap_meta_box_nonce']) && !isset($_POST['cert_roadmap_meta_box_nonce'])) {
        return;
    }
    
    if (isset($_POST['career_roadmap_meta_box_nonce'])) {
        if (!wp_verify_nonce($_POST['career_roadmap_meta_box_nonce'], 'career_roadmap_meta_box')) {
            return;
        }
    }
    
    if (isset($_POST['cert_roadmap_meta_box_nonce'])) {
        if (!wp_verify_nonce($_POST['cert_roadmap_meta_box_nonce'], 'cert_roadmap_meta_box')) {
            return;
        }
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $fields = array(
        'tcr_icon', 'tcr_short_description', 'tcr_color', 'tcr_avg_salary', 'tcr_duration', 
        'tcr_experience_level', 'tcr_skills', 'tcr_provider', 
        'tcr_level', 'tcr_exam_cost', 'tcr_estimated_time', 'tcr_learning_path'
    );
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
    
public function enqueue_assets() {
    wp_enqueue_style('tcr-styles', TCR_PLUGIN_URL . 'assets/roadmap-styles.css', array(), TCR_VERSION);
    
    wp_enqueue_script('tcr-roadmap', TCR_PLUGIN_URL . 'assets/roadmap-app.js', array('jquery'), TCR_VERSION, true);
    
    wp_localize_script('tcr-roadmap', 'tcrAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('tcr_ajax_nonce')
    ));
}

public function dynamic_roadmap_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => 0,
        'type' => 'career', // 'career' or 'certification'
        'title' => '',
        'description' => '',
        'short_description' => '',
        'icon' => '',
        'color' => '',
        // Career-specific attributes
        'salary' => '',
        'duration' => '',
        'level' => 'Beginner',
        'skills' => '',
        // Certification-specific attributes
        'provider' => '',
        'exam_cost' => '',
        'estimated_time' => '',
        // Module/learning path (JSON string)
        'modules' => '',
        // Action: 'create', 'update', or 'display' (default)
        'action' => 'display'
    ), $atts);
    
    // If action is create or update, handle that
    if ($atts['action'] === 'create' || $atts['action'] === 'update') {
        return $this->handle_roadmap_crud($atts);
    }
    
    // Otherwise, display the roadmap
    if ($atts['id']) {
        $post_type = $atts['type'] === 'certification' ? 'cert_roadmap' : 'career_roadmap';
        
        if ($atts['type'] === 'certification') {
            return $this->certification_roadmap_shortcode(array('id' => $atts['id']));
        } else {
            return $this->career_roadmap_shortcode(array('id' => $atts['id']));
        }
    }
    
    return '<p>Please provide a roadmap ID or action.</p>';
}

/**
 * Handle create/update operations for roadmaps
 */
private function handle_roadmap_crud($atts) {
    // Check if user has permission
    if (!current_user_can('edit_posts')) {
        return '<p style="color: red;">Error: You do not have permission to create/update roadmaps.</p>';
    }
    
    $post_type = $atts['type'] === 'certification' ? 'cert_roadmap' : 'career_roadmap';
    
    // Prepare post data
    $post_data = array(
        'post_type' => $post_type,
        'post_status' => 'publish'
    );
    
    if ($atts['action'] === 'create') {
        // Create new post
        if (empty($atts['title'])) {
            return '<p style="color: red;">Error: Title is required for creating a roadmap.</p>';
        }
        
        $post_data['post_title'] = sanitize_text_field($atts['title']);
        $post_data['post_content'] = wp_kses_post($atts['description']);
        
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            return '<p style="color: red;">Error creating roadmap: ' . $post_id->get_error_message() . '</p>';
        }
        
    } elseif ($atts['action'] === 'update') {
        // Update existing post
        if (empty($atts['id'])) {
            return '<p style="color: red;">Error: ID is required for updating a roadmap.</p>';
        }
        
        $post_id = intval($atts['id']);
        $existing_post = get_post($post_id);
        
        if (!$existing_post || $existing_post->post_type !== $post_type) {
            return '<p style="color: red;">Error: Roadmap not found or type mismatch.</p>';
        }
        
        $post_data['ID'] = $post_id;
        
        if (!empty($atts['title'])) {
            $post_data['post_title'] = sanitize_text_field($atts['title']);
        }
        
        if (!empty($atts['description'])) {
            $post_data['post_content'] = wp_kses_post($atts['description']);
        }
        
        wp_update_post($post_data);
    }
    
    // Update meta fields
    if (!empty($atts['icon'])) {
        update_post_meta($post_id, '_tcr_icon', sanitize_text_field($atts['icon']));
    }
    
    if (!empty($atts['short_description'])) {
        update_post_meta($post_id, '_tcr_short_description', sanitize_text_field($atts['short_description']));
    }
    
    if (!empty($atts['color'])) {
        update_post_meta($post_id, '_tcr_color', sanitize_text_field($atts['color']));
    }
    
    // Type-specific meta
    if ($atts['type'] === 'career') {
        if (!empty($atts['salary'])) {
            update_post_meta($post_id, '_tcr_avg_salary', sanitize_text_field($atts['salary']));
        }
        if (!empty($atts['duration'])) {
            update_post_meta($post_id, '_tcr_duration', sanitize_text_field($atts['duration']));
        }
        if (!empty($atts['level'])) {
            update_post_meta($post_id, '_tcr_experience_level', sanitize_text_field($atts['level']));
        }
        if (!empty($atts['skills'])) {
            update_post_meta($post_id, '_tcr_skills', sanitize_text_field($atts['skills']));
        }
    } else {
        if (!empty($atts['provider'])) {
            update_post_meta($post_id, '_tcr_provider', sanitize_text_field($atts['provider']));
        }
        if (!empty($atts['level'])) {
            update_post_meta($post_id, '_tcr_level', sanitize_text_field($atts['level']));
        }
        if (!empty($atts['exam_cost'])) {
            update_post_meta($post_id, '_tcr_exam_cost', sanitize_text_field($atts['exam_cost']));
        }
        if (!empty($atts['estimated_time'])) {
            update_post_meta($post_id, '_tcr_estimated_time', sanitize_text_field($atts['estimated_time']));
        }
    }
    
    // Handle modules/learning path
    if (!empty($atts['modules'])) {
        // Decode JSON string if provided
        $modules = json_decode($atts['modules'], true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($modules)) {
            update_post_meta($post_id, '_tcr_learning_path', wp_json_encode($modules));
        }
    }
    
    $action_text = $atts['action'] === 'create' ? 'created' : 'updated';
    return '<div style="padding: 1rem; background: #d1f4e0; border-left: 4px solid #10b981; border-radius: 4px; margin: 1rem 0;">
        <strong>Success!</strong> Roadmap ' . $action_text . ' successfully! 
        <a href="' . get_permalink($post_id) . '" style="color: #059669; text-decoration: underline;">View Roadmap</a> | 
        <a href="' . admin_url('post.php?post=' . $post_id . '&action=edit') . '" style="color: #059669; text-decoration: underline;">Edit in Admin</a>
    </div>';
}

/**
 * Shortcode for adding modules to existing roadmaps
 * Usage: [td_roadmap_module roadmap_id="1" title="Module Title" description="Short desc" subgoals='[{"title":"Goal 1","resources":[{"name":"Link","url":"http://..."}]}]']
 */
public function roadmap_module_shortcode($atts) {
    $atts = shortcode_atts(array(
        'roadmap_id' => 0,
        'title' => '',
        'description' => '',
        'subgoals' => '',
        'action' => 'add' // 'add' or 'replace'
    ), $atts);
    
    if (!current_user_can('edit_posts')) {
        return '<p style="color: red;">Error: Permission denied.</p>';
    }
    
    if (empty($atts['roadmap_id']) || empty($atts['title'])) {
        return '<p style="color: red;">Error: roadmap_id and title are required.</p>';
    }
    
    $post_id = intval($atts['roadmap_id']);
    $post = get_post($post_id);
    
    if (!$post || ($post->post_type !== 'career_roadmap' && $post->post_type !== 'cert_roadmap')) {
        return '<p style="color: red;">Error: Invalid roadmap ID.</p>';
    }
    
    // Get existing learning path
    $learning_path = json_decode(get_post_meta($post_id, '_tcr_learning_path', true), true) ?: array();
    
    // Parse subgoals
    $subgoals = json_decode($atts['subgoals'], true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $subgoals = array();
    }
    
    // Create new module
    $new_module = array(
        'title' => sanitize_text_field($atts['title']),
        'shortDesc' => sanitize_text_field($atts['description']),
        'subGoals' => $subgoals
    );
    
    if ($atts['action'] === 'replace') {
        $learning_path = array($new_module);
    } else {
        $learning_path[] = $new_module;
    }
    
    update_post_meta($post_id, '_tcr_learning_path', wp_json_encode($learning_path));
    
    return '<div style="padding: 1rem; background: #d1f4e0; border-left: 4px solid #10b981; border-radius: 4px; margin: 1rem 0;">
        <strong>Success!</strong> Module added to roadmap! 
        <a href="' . get_permalink($post_id) . '" style="color: #059669; text-decoration: underline;">View Roadmap</a>
    </div>';
}

public function career_roadmap_shortcode($atts) {
    $atts = shortcode_atts(array('id' => 0), $atts);
    
    if (!$atts['id']) {
        return '<p>Please provide a roadmap ID.</p>';
    }
    
    $post = get_post($atts['id']);
    if (!$post || $post->post_type !== 'career_roadmap') {
        return '<p>Roadmap not found.</p>';
    }
    
    $data = $this->get_roadmap_data($post);
    
    ob_start();
    include TCR_PLUGIN_DIR . 'templates/roadmap-single.php';
    return ob_get_clean();
}
    
public function certification_roadmap_shortcode($atts) {
    $atts = shortcode_atts(array('id' => 0), $atts);
    
    if (!$atts['id']) {
        return '<p>Please provide a certification ID.</p>';
    }
    
    $post = get_post($atts['id']);
    if (!$post || $post->post_type !== 'cert_roadmap') {
        return '<p>Certification not found.</p>';
    }
    
    $data = $this->get_roadmap_data($post);
    
    ob_start();
    include TCR_PLUGIN_DIR . 'templates/roadmap-single.php';
    return ob_get_clean();
}
    
public function roadmap_home_shortcode($atts) {
    $career_roadmaps = get_posts(array(
        'post_type' => 'career_roadmap',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'orderby' => 'date',
        'order' => 'ASC'
    ));
    
    $cert_roadmaps = get_posts(array(
        'post_type' => 'cert_roadmap',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    ));
    
    ob_start();
    include TCR_PLUGIN_DIR . 'templates/roadmap-home.php';
    return ob_get_clean();
}

/**
 * Shortcode to display roadmap cards only (without full homepage)
 * Usage: [roadmap_cards type="career"] or [roadmap_cards type="certification"] or [roadmap_cards type="both"]
 */
public function roadmap_cards_shortcode($atts) {
    $atts = shortcode_atts(array(
        'type' => 'both', // 'career', 'certification', or 'both'
        'limit' => -1,    // Number of cards to show (-1 for all)
        'ids' => '',      // Comma-separated list of specific IDs to show
    ), $atts);
    
    $output = '';
    
    // Parse specific IDs if provided
    $specific_ids = array();
    if (!empty($atts['ids'])) {
        $specific_ids = array_map('intval', explode(',', $atts['ids']));
    }
    
    // Determine which types to show
    $show_career = ($atts['type'] === 'both' || $atts['type'] === 'career');
    $show_cert = ($atts['type'] === 'both' || $atts['type'] === 'certification');
    
    // Include Material Icons
    $output .= '<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">';
    $output .= '<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">';
    
    $output .= '<div class="tcr-cards-only-wrapper" style="background-color: #f7fafc; padding: 2rem 0;">';
    $output .= '<div class="tcr-content-area">';
    
    // Career Roadmaps
    if ($show_career) {
        $career_args = array(
            'post_type' => 'career_roadmap',
            'posts_per_page' => intval($atts['limit']),
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'ASC'
        );
        
        if (!empty($specific_ids)) {
            $career_args['post__in'] = $specific_ids;
        }
        
        $career_roadmaps = get_posts($career_args);
        
        if (!empty($career_roadmaps)) {
            $output .= '<div class="tcr-card-grid">';
            
            foreach ($career_roadmaps as $roadmap) {
                $roadmap_id = $roadmap->ID;
                $icon = get_post_meta($roadmap_id, '_tcr_icon', true) ?: '💼';
                $color = get_post_meta($roadmap_id, '_tcr_color', true);
                
                if (empty($color)) {
                    $color = '#3b82f6, #8b5cf6';
                }
                
                $colors = array_map('trim', explode(',', $color));
                $color1 = isset($colors[0]) && !empty($colors[0]) ? $colors[0] : '#3b82f6';
                $color2 = isset($colors[1]) && !empty($colors[1]) ? $colors[1] : '#8b5cf6';
                
                $avg_salary = get_post_meta($roadmap_id, '_tcr_avg_salary', true) ?: 'N/A';
                $duration = get_post_meta($roadmap_id, '_tcr_duration', true) ?: 'N/A';
                $experience_level = get_post_meta($roadmap_id, '_tcr_experience_level', true) ?: 'Intermediate';
                
                $learning_path = json_decode(get_post_meta($roadmap_id, '_tcr_learning_path', true), true) ?: array();
                $modules_count = count($learning_path);
                
                $skills = get_post_meta($roadmap_id, '_tcr_skills', true) ?: '';
                $skills_array = array_filter(array_map('trim', explode(',', $skills)));
                
                $output .= '<a href="' . esc_url(get_permalink($roadmap_id)) . '" style="text-decoration: none; display: block;">';
                $output .= '<div class="card" style="cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease;" onmouseover="this.style.transform=\'translateY(-4px)\'; this.style.boxShadow=\'0 12px 24px rgba(0,0,0,0.15)\';" onmouseout="this.style.transform=\'translateY(0)\'; this.style.boxShadow=\'\';">';
                $output .= '<div style="padding: 2rem;">';
                
                // Header with icon and title
                $output .= '<div style="display: flex; align-items: flex-start; gap: 1rem; margin-bottom: 1rem;">';
                $output .= '<div class="icon-badge text-white" style="background: linear-gradient(135deg, ' . esc_attr($color1) . ', ' . esc_attr($color2) . ');">';
                $output .= esc_html($icon);
                $output .= '</div>';
                $output .= '<div style="flex: 1; min-width: 0;">';
                $output .= '<h3 style="font-size: 1.5rem; font-weight: 900; color: #1f2937; margin-top: 0; margin-bottom: 0.25rem;">';
                $output .= esc_html($roadmap->post_title);
                $output .= '</h3>';
                $output .= '<p style="font-size: 0.875rem; color: #6b7280; margin: 0;">';
                $output .= esc_html(wp_trim_words($roadmap->post_content, 15, '...'));
                $output .= '</p>';
                $output .= '</div>';
                $output .= '</div>';
                
                // Stats grid
                $output .= '<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.75rem; margin-bottom: 1rem;">';
                
                $output .= '<div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.75rem;">';
                $output .= '<div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">';
                $output .= '<span class="material-icons" style="font-size: 0.875rem;">payments</span> Avg. Salary';
                $output .= '</div>';
                $output .= '<div style="font-weight: 600; color: #1f2937;">' . esc_html($avg_salary) . '</div>';
                $output .= '</div>';
                
                $output .= '<div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.75rem;">';
                $output .= '<div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">';
                $output .= '<span class="material-icons" style="font-size: 0.875rem;">schedule</span> Duration';
                $output .= '</div>';
                $output .= '<div style="font-weight: 600; color: #1f2937;">' . esc_html($duration) . '</div>';
                $output .= '</div>';
                
                $output .= '<div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.75rem;">';
                $output .= '<div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">';
                $output .= '<span class="material-icons" style="font-size: 0.875rem;">list_alt</span> Modules';
                $output .= '</div>';
                $output .= '<div style="font-weight: 600; color: #1f2937;">' . esc_html($modules_count) . '</div>';
                $output .= '</div>';
                
                $output .= '</div>';
                
                // Skills tags
                if (!empty($skills_array)) {
                    $output .= '<div style="margin-bottom: 1rem;">';
                    $output .= '<div style="font-size: 0.75rem; font-weight: 600; color: #6b7280; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.25rem;">';
                    $output .= '<span class="material-icons" style="font-size: 0.875rem;">psychology</span> KEY SKILLS';
                    $output .= '</div>';
                    $output .= '<div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">';
                    foreach (array_slice($skills_array, 0, 5) as $skill) {
                        $output .= '<span class="tcr-skill-tag">' . esc_html($skill) . '</span>';
                    }
                    $output .= '</div>';
                    $output .= '</div>';
                }
                
                // View roadmap link
                $output .= '<div style="border-top: 1px solid #e5e7eb; padding-top: 1rem;">';
                $output .= '<span style="color: #fb923c; font-weight: 600; text-decoration: none; font-size: 1rem; display: flex; align-items: center; gap: 0.25rem;" onmouseover="this.style.color=\'#c2410c\';" onmouseout="this.style.color=\'#fb923c\';" onfocus="this.style.outline=\'none\';">';
                $output .= 'View Roadmap <span class="material-icons" style="font-size: 1.125rem;">arrow_forward</span>';
                $output .= '</span>';
                $output .= '</div>';
                
                $output .= '</div>';
                $output .= '</div>';
                $output .= '</a>';
            }
            
            $output .= '</div>';
        }
    }
    
    // Certification Roadmaps
    if ($show_cert) {
        $cert_args = array(
            'post_type' => 'cert_roadmap',
            'posts_per_page' => intval($atts['limit']),
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'ASC'
        );
        
        if (!empty($specific_ids)) {
            $cert_args['post__in'] = $specific_ids;
        }
        
        $cert_roadmaps = get_posts($cert_args);
        
        if (!empty($cert_roadmaps)) {
            // Add spacing if both types are shown
            if ($show_career && !empty($career_roadmaps)) {
                $output .= '<div style="margin-top: 3rem;"></div>';
            }
            
            $output .= '<div class="tcr-card-grid">';
            
            foreach ($cert_roadmaps as $cert) {
                $cert_id = $cert->ID;
                $icon = get_post_meta($cert_id, '_tcr_icon', true) ?: '🏆';
                $color = get_post_meta($cert_id, '_tcr_color', true);
                
                if (empty($color)) {
                    $color = '#10b981, #14b8a6';
                }
                
                $colors = array_map('trim', explode(',', $color));
                $color1 = isset($colors[0]) && !empty($colors[0]) ? $colors[0] : '#10b981';
                $color2 = isset($colors[1]) && !empty($colors[1]) ? $colors[1] : '#14b8a6';
                
                $provider = get_post_meta($cert_id, '_tcr_provider', true) ?: 'N/A';
                $level = get_post_meta($cert_id, '_tcr_level', true) ?: 'Associate';
                $exam_cost = get_post_meta($cert_id, '_tcr_exam_cost', true) ?: 'N/A';
                $estimated_time = get_post_meta($cert_id, '_tcr_estimated_time', true) ?: 'N/A';
                
                $output .= '<a href="' . esc_url(get_permalink($cert_id)) . '" style="text-decoration: none; display: block;">';
                $output .= '<div class="card" style="cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease;" onmouseover="this.style.transform=\'translateY(-4px)\'; this.style.boxShadow=\'0 12px 24px rgba(0,0,0,0.15)\';" onmouseout="this.style.transform=\'translateY(0)\'; this.style.boxShadow=\'\';">';
                $output .= '<div style="padding: 2rem;">';
                
                // Header
                $output .= '<div style="display: flex; align-items: flex-start; gap: 1rem; margin-bottom: 0.5rem;">';
                $output .= '<div class="icon-badge text-white" style="background: linear-gradient(135deg, ' . esc_attr($color1) . ', ' . esc_attr($color2) . ');">';
                $output .= esc_html($icon);
                $output .= '</div>';
                $output .= '<div style="flex: 1; min-width: 0;">';
                $output .= '<div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem; flex-wrap: wrap;">';
                $output .= '<h3 style="font-size: 1.25rem; font-weight: 900; color: #1f2937; margin-top: 0; margin-bottom: 0.25rem;">';
                $output .= esc_html($cert->post_title);
                $output .= '</h3>';
                $output .= '<span style="padding: 0.25rem 0.5rem; background-color: #dbeafe; color: #1d4ed8; font-size: 0.75rem; font-weight: 600; border-radius: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">';
                $output .= '<span class="material-icons" style="font-size: 0.875rem;">military_tech</span>' . esc_html($level);
                $output .= '</span>';
                $output .= '</div>';
                $output .= '</div>';
                $output .= '</div>';
                
                // Stats
                $output .= '<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.75rem; margin-bottom: 0.75rem;">';
                
                $output .= '<div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.5rem;">';
                $output .= '<div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">';
                $output .= '<span class="material-icons" style="font-size: 0.875rem;">schedule</span> Study Time';
                $output .= '</div>';
                $output .= '<div style="font-weight: 600; color: #1f2937; font-size: 1rem;">' . esc_html($estimated_time) . '</div>';
                $output .= '</div>';
                
                $output .= '<div style="background-color: #f9fafb; border-radius: 0.5rem; padding: 0.5rem;">';
                $output .= '<div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem; display: flex; align-items: center; gap: 0.25rem;">';
                $output .= '<span class="material-icons" style="font-size: 0.875rem;">payments</span> Exam Cost';
                $output .= '</div>';
                $output .= '<div style="font-weight: 600; color: #1f2937; font-size: 1rem;">' . esc_html($exam_cost) . '</div>';
                $output .= '</div>';
                
                $output .= '</div>';
                
                // View roadmap link
                $output .= '<div style="border-top: 1px solid #e5e7eb; padding-top: 0.75rem;">';
                $output .= '<span style="color: #fb923c; font-weight: 600; text-decoration: none; font-size: 1rem; display: flex; align-items: center; gap: 0.25rem;" onmouseover="this.style.color=\'#c2410c\';" onmouseout="this.style.color=\'#fb923c\';" onfocus="this.style.outline=\'none\';">';
                $output .= 'View Roadmap <span class="material-icons" style="font-size: 1.125rem;">arrow_forward</span>';
                $output .= '</span>';
                $output .= '</div>';
                
                $output .= '</div>';
                $output .= '</div>';
                $output .= '</a>';
            }
            
            $output .= '</div>';
        }
    }
    
    $output .= '</div>';
    $output .= '</div>';
    
    return $output;
}
    
public function get_roadmap_data($post) {
    $is_career = $post->post_type === 'career_roadmap';
    
    $data = array(
        'id' => $post->ID,
        'title' => $post->post_title,
        'description' => $post->post_content,
        'icon' => get_post_meta($post->ID, '_tcr_icon', true),
        'color' => get_post_meta($post->ID, '_tcr_color', true),
        'learningPath' => json_decode(get_post_meta($post->ID, '_tcr_learning_path', true), true) ?: array(),
    );
    
    if ($is_career) {
        $data['avgSalary'] = get_post_meta($post->ID, '_tcr_avg_salary', true);
        $data['duration'] = get_post_meta($post->ID, '_tcr_duration', true);
        $data['experienceLevel'] = get_post_meta($post->ID, '_tcr_experience_level', true);
        $data['skills'] = explode(',', get_post_meta($post->ID, '_tcr_skills', true));
        $data['modules'] = count($data['learningPath']);
    } else {
        $data['provider'] = get_post_meta($post->ID, '_tcr_provider', true);
        $data['level'] = get_post_meta($post->ID, '_tcr_level', true);
        $data['examCost'] = get_post_meta($post->ID, '_tcr_exam_cost', true);
        $data['estimatedTime'] = get_post_meta($post->ID, '_tcr_estimated_time', true);
    }
    
    return $data;
}
    
public function save_progress() {
    check_ajax_referer('tcr_ajax_nonce', 'nonce');
    
    $roadmap_id = intval($_POST['roadmap_id']);
    $progress = json_decode(stripslashes($_POST['progress']), true);
    
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        update_user_meta($user_id, 'tcr_progress_' . $roadmap_id, $progress);
    } else {
        if (!session_id()) {
            session_start();
        }
        $_SESSION['tcr_progress_' . $roadmap_id] = $progress;
    }
    
    wp_send_json_success();
}
    
public function get_progress() {
    check_ajax_referer('tcr_ajax_nonce', 'nonce');
    
    $roadmap_id = intval($_POST['roadmap_id']);
    
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $progress = get_user_meta($user_id, 'tcr_progress_' . $roadmap_id, true);
    } else {
        if (!session_id()) {
            session_start();
        }
        $progress = isset($_SESSION['tcr_progress_' . $roadmap_id]) ? $_SESSION['tcr_progress_' . $roadmap_id] : array();
    }
    
    wp_send_json_success($progress);
}
}

new TechCareerRoadmaps();